<?php
include 'config.php';
$blood_group_ID=1;
$blood_group = isset($_GET['blood_group']) ? intval($_GET['blood_group']) : '';
$wilaya = isset($_GET['wilaya']) ? intval($_GET['wilaya']) : '';
$daira = isset($_GET['daira']) ? intval($_GET['daira']) : '';
$sql = "SELECT id FROM blood_groups WHERE bloodGroup = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $blood_group);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $blood_group_ID = $row['id'];
}
$query = "SELECT bd.*, u.name, u.phone, u.readyToGive, w.name AS wilaya_name, d.name AS daira_name, bg.bloodGroup 
          FROM blod_donors bd
          INNER JOIN users u ON bd.user_id = u.id
          LEFT JOIN wilayas w ON u.wilaya_id = w.id
          LEFT JOIN dairas d ON u.daira_id = d.id
          LEFT JOIN blood_groups bg ON u.blood_group_id = bg.id
          WHERE u.readyToGive = 1"; // جلب المتبرعين الجاهزين فقط

if (!empty($blood_group)) {
    $query .= " AND u.blood_group_id = $blood_group";
}
if (!empty($wilaya)) {
    $query .= " AND u.wilaya_id = $wilaya";
}
if (!empty($daira)) {
    $query .= " AND u.daira_id = $daira";
}

$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='container shadow-lg donorCard d-flex flex-column'>
                <div class='donorInfo px-3 py-3 row'>
                    <div class='infos col-9'>
                        <span class='text-danger fs-4'><strong class='text-dark'>Province:</strong> " . $row['wilaya_name'] . "</span><br>
                        <span class='text-danger fs-4'><strong class='text-dark'>Governorate:</strong> " . $row['daira_name'] . "</span>
                    </div>
                    <div class='bloodGroup col-3 d-flex align-items-center'>
                        <span class='text-danger'>" . $row['bloodGroup'] . "</span>
                    </div>
                </div>
                <div class='donorPhone bg-danger p-3 bg-light row'>
                    <strong class='align-items-center justify-content-center d-flex col-12 text-lg-center text-success fs-4' style='user-select: all;'>
                        <svg class='d-none d-lg-inline bg-success rounded-circle phoneIcon' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'>
                            <path d='M511.2 387l-23.25 100.8c-3.266 14.25-15.79 24.22-30.46 24.22C205.2 512 0 306.8 0 54.5c0-14.66 9.969-27.2 24.22-30.45l100.8-23.25C139.7-2.602 154.7 5.018 160.8 18.92l46.52 108.5c5.438 12.78 1.77 27.67-8.98 36.45L144.5 207.1c33.98 69.22 90.26 125.5 159.5 159.5l44.08-53.8c8.688-10.78 23.69-14.51 36.47-8.975l108.5 46.51C506.1 357.2 514.6 372.4 511.2 387z'/>
                        </svg>
                        <span>" . $row['phone'] . "</span>
                    </strong>
                </div>
              </div>";
    }
} else {
    echo "<p class='text-center text-danger'>لم يتم العثور على متبرعين.</p>";
}

$conn->close();
?>
