<?php

    include 'config.php';
?>



<!doctype html>
<html lang="en" dir="ltr">
<head>
  <title>DonateLife | About Us</title>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <meta property="og:type" content="website">
  <meta property="og:url" content="about">
  <meta property="og:title" content="DonateLife | About Us">

  <meta property="og:image" content="imgs/organDonationImage.jpg">
  <meta property="og:locale" content="en_US">

  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:url" content="about">
  <meta property="twitter:title" content="DonateLife | About Us">

  <meta property="twitter:image" content="imgs/organDonationImage.jpg">



    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600&family=Nunito:wght@600;700&display=swap"
        rel="stylesheet">

            <link rel="preload" as="style" href="  build/assets/bootstrap-rtl.6923a990.css" /><link rel="stylesheet" href="  build/assets/bootstrap-rtl.6923a990.css" />
    <link rel="preload" as="style" href="  build/assets/app.1fd5bbb5.css" /><link rel="stylesheet" href="  build/assets/app.1fd5bbb5.css" />
        <link rel="preload" as="style" href="  build/assets/aboutPage.8381195d.css" /><link rel="preload" as="style" href="  build/assets/cta.914a397d.css" /><link rel="preload" as="style" href="  build/assets/stats.431c0330.css" /><link rel="stylesheet" href="  build/assets/aboutPage.8381195d.css" /><link rel="stylesheet" href="  build/assets/cta.914a397d.css" /><link rel="stylesheet" href="  build/assets/stats.431c0330.css" />

        <script data-turbo-eval="false">jQuery.noConflict(true);</script>

</head>

<body>
<?php
    include "header.php";
?>

<div class="aboutPageHero bg-dark d-flex flex-column align-items-center justify-content-center mb-5">
    <h1 class="text-white display-4">Our Mission</h1>
    <p class="text-white text-center ourMissionDescription">  
        Our mission is to save lives across Saudi Arabia by creating a network that connects those in need with organ donors quickly and easily, making organ donation a simpler and more effective process, just like searching on Google.  
    </p>
</div>

<div>
    <div class="container col-xxl-8 px-4 py-5 hero">
        <div class="row align-items-center g-5 mb-5">
            <div class="col-lg-6 mt-xl-0">
                <h1 class="headline display-5 fw-bold lh-1 mb-3 text-center text-lg-start">Who We Are</h1>
                <p class="lead text-center text-lg-start">
                    We believe that life is a precious gift, and giving it to others is the greatest act of charity. Through our platform, we aim to simplify the process of organ donation, connecting donors with those in need quickly and easily. This helps save lives and brings hope to those in need. Together, we make a difference and build a community based on humanity and solidarity.
                </p>
            </div>
            <div class="d-none d-lg-block col-12 col-lg-6 d-flex flex-column align-items-center mb-5">
                <img src="imgs/whoAreWe.svg" class="d-lg-block mx-lg-auto img-fluid" width="700" height="500" loading="lazy">
            </div>
        </div>
    </div>

    <div class="container col-xxl-8 px-4 py-5 hero">
        <div class="row align-items-center g-5 mb-5">
            <div class="d-none d-lg-block col-12 col-lg-6 d-flex flex-column align-items-center mb-5">
                <img src="imgs/motivation.svg" class="d-block mx-lg-auto img-fluid" width="700" height="500" loading="lazy">
            </div>

            <div class="col-lg-6 mt-xl-0">
                <h1 class="headline display-5 fw-bold lh-1 mb-3 text-center text-lg-start">The Motivation</h1>
                <p class="lead text-center text-lg-start">
                    How many times have you heard about someone desperately needing an organ donor or a patient waiting for a second chance at life through a transplant? These situations occur daily, and many struggle to find donors in time. In some cases, delays can be a matter of life or death. This is why our platform was created—to bridge the gap between those in need of organs and those who can donate. Saving lives is the greatest form of giving, and every donation offers a new hope to those in dire need.
                </p>
            </div>
        </div>
    </div>

    <div class="container col-xxl-8 px-4 py-5 hero">
        <div class="row align-items-center g-5 mb-5">
            <div class="col-lg-6 mt-xl-0">
                <h1 class="headline display-5 fw-bold lh-1 mb-3 text-center text-lg-start">Our Vision</h1>
                <p class="lead text-center text-lg-start">  
                    Simply put, finding organ donors will no longer be a problem. If you need a donor, our platform allows you to search quickly and connect with thousands of nearby donors, making it easier to save lives in critical moments.  
                </p>
            </div>

            <div class="d-none d-lg-block col-12 col-lg-6 d-flex flex-column align-items-center mb-5">
                <img src="imgs/vision.svg" class="d-block mx-lg-auto img-fluid" width="700" height="500" loading="lazy">
            </div>
        </div>
    </div>
</div>


    <section class="cta py-5 my-5 bg-dark">

      <div class="container d-flex flex-column align-items-center">
      <p class="text-white fs-2 text-center">Be the reason someone gets a second chance – Donate organs</p>  
      <p class="text-white text-center fs-5">  
      The best way to help is by registering as an organ donor. Every donation can give a new life to someone in need. If you're unable to donate, you can always spread the message and share this website on social media to reach those who need help.  
      </p>

          <p class="text-white fs-3">Share this website on:</p>
      </div>

      <div class="shareBtns container d-flex flex-column flex-sm-row flex-wrap align-items-center justify-content-center">

          <a href="#" class="fbShare btn d-flex align-items-center justify-content-center" target="_blank" rel="nofollow">
              <svg class="fa-brands fa-facebook" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"/></svg>
              <span class="ms-2">Facebook</span>
          </a>

          <a href="#" class="messengerShare btn d-flex align-items-center justify-content-center my-3 my-lg-0 mx-sm-3" target="_blank" rel="nofollow">
              <svg class="fa-brands fa-facebook-messenger" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M256.55 8C116.52 8 8 110.34 8 248.57c0 72.3 29.71 134.78 78.07 177.94 8.35 7.51 6.63 11.86 8.05 58.23A19.92 19.92 0 0 0 122 502.31c52.91-23.3 53.59-25.14 62.56-22.7C337.85 521.8 504 423.7 504 248.57 504 110.34 396.59 8 256.55 8zm149.24 185.13l-73 115.57a37.37 37.37 0 0 1-53.91 9.93l-58.08-43.47a15 15 0 0 0-18 0l-78.37 59.44c-10.46 7.93-24.16-4.6-17.11-15.67l73-115.57a37.36 37.36 0 0 1 53.91-9.93l58.06 43.46a15 15 0 0 0 18 0l78.41-59.38c10.44-7.98 24.14 4.54 17.09 15.62z"/></svg>
              <span class="ms-2">Messenger</span>
          </a>

          <a href="#" class="whatsappShare btn d-flex align-items-center justify-content-center" target="_blank" rel="nofollow">
              <svg class="fa-brands fa-whatsapp" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/></svg>
              <span class="ms-2">Whatsapp</span>
          </a>

      </div>

    </section>

    

<?php
    include "Organ_Donor_Statistics.php";
?>



<?php
    include "footer.php";
?>





<link rel="modulepreload" href="build/assets/app.375cedd6.js" />
<script type="module" src="build/assets/app.375cedd6.js"></script>

</body>

</html>
