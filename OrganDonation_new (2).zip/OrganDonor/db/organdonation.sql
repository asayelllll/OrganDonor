-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2025 at 12:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `organdonation`
--

-- --------------------------------------------------------

--
-- Table structure for table `blood_groups`
--

CREATE TABLE `blood_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bloodGroup` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blood_groups`
--

INSERT INTO `blood_groups` (`id`, `bloodGroup`) VALUES
(1, 'A+'),
(2, 'A-'),
(3, 'B+'),
(4, 'B-'),
(5, 'O+'),
(6, 'O-'),
(7, 'AB+'),
(8, 'AB-');

-- --------------------------------------------------------

--
-- Table structure for table `dairas`
--

CREATE TABLE `dairas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` tinytext NOT NULL,
  `wilaya_id` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dairas`
--

INSERT INTO `dairas` (`id`, `name`, `wilaya_id`) VALUES
(1, 'Dammam', 1),
(2, 'Khobar', 1),
(3, 'Al-Ahsa', 1),
(4, 'Jubail', 1),
(5, 'Qatif', 1),
(6, 'Mecca', 2),
(7, 'Jeddah', 2),
(8, 'Taif', 2),
(9, 'Rabigh', 2),
(10, 'Al-Qunfudhah', 2),
(11, 'Riyadh', 3),
(12, 'Diriyah', 3),
(13, 'Al-Majmaah', 3),
(14, 'Al-Kharj', 3),
(15, 'Wadi ad-Dawasir', 3),
(16, 'Abha', 4),
(17, 'Khamis Mushait', 4),
(18, 'Mahail', 4),
(19, 'Balqarn', 4),
(20, 'Medina', 5),
(21, 'Yanbu', 5),
(22, 'AlUla', 5),
(23, 'Badr', 5),
(24, 'Buraidah', 6),
(25, 'Unayzah', 6),
(26, 'Al-Mithnab', 6),
(27, 'Tabuk', 7),
(28, 'Duba', 7),
(29, 'Umluj', 7),
(30, 'Jizan', 8),
(31, 'Sabya', 8),
(32, 'Abu Arish', 8),
(33, 'Najran', 9),
(34, 'Sharurah', 9),
(35, 'Habouna', 9),
(36, 'Arar', 10),
(37, 'Rafha', 10),
(38, 'Turaif', 10),
(39, 'Al-Bahah', 11),
(40, 'Al-Mukhwah', 11),
(41, 'Qilwah', 11),
(42, 'Sakaka', 12),
(43, 'Dumat Al-Jandal', 12),
(44, 'Al-Qurayyat', 12);

-- --------------------------------------------------------

--
-- Table structure for table `donated_organs`
--

CREATE TABLE `donated_organs` (
  `id` int(11) NOT NULL,
  `organs_type` int(11) NOT NULL,
  `organs_status` varchar(1000) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `donation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `organs_groups`
--

CREATE TABLE `organs_groups` (
  `id` int(11) NOT NULL,
  `organs_name` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organs_groups`
--

INSERT INTO `organs_groups` (`id`, `organs_name`) VALUES
(1, 'Heart'),
(2, 'Liver'),
(3, 'Kidneys'),
(4, 'Lungs'),
(5, 'Pancreas'),
(6, 'Intestines'),
(7, 'Cornea'),
(8, 'Skin'),
(9, 'Bones'),
(10, 'Blood Vessels');

-- --------------------------------------------------------

--
-- Table structure for table `organs_recipients`
--

CREATE TABLE `organs_recipients` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `medical_diagnosis` varchar(10000) NOT NULL,
  `organs_type` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `organ_donors`
--

CREATE TABLE `organ_donors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `donor_name` varchar(1000) NOT NULL,
  `donor_gender` varchar(100) NOT NULL,
  `blood` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `organ` int(11) NOT NULL,
  `donation_date` date DEFAULT NULL,
  `medical_conditions` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `Health_status` varchar(1000) NOT NULL,
  `Donation_Status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `organ_donors`
--

INSERT INTO `organ_donors` (`id`, `donor_name`, `donor_gender`, `blood`, `user_id`, `organ`, `donation_date`, `medical_conditions`, `status`, `created_at`, `updated_at`, `Health_status`, `Donation_Status`) VALUES
(1, '', '', '', 2, 8, '2025-02-09', 'لا استخدم اي دواء', 'pending', NULL, NULL, 'لايوجد اي مرض', 'alive'),
(2, 'محمد نبيل محمد القحطاني', 'male', '6', 4, 2, '2025-03-09', 'لا استخدم اي دواء', 'pending', NULL, NULL, 'nothings ', 'alive');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `readyToGive` tinyint(1) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `wilaya_id` tinyint(4) NOT NULL,
  `daira_id` bigint(20) UNSIGNED NOT NULL,
  `blood_group_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(1000) NOT NULL,
  `date_birthday` date NOT NULL,
  `address` varchar(1000) NOT NULL,
  `gender` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `phone`, `readyToGive`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `created_at`, `updated_at`, `wilaya_id`, `daira_id`, `blood_group_id`, `name`, `date_birthday`, `address`, `gender`) VALUES
(2, 'm@gmail.com', '0772426711', 1, NULL, '$2y$10$iRUQU52n2rqKa7B3PtYir.daHDXHeexOpP2qPicsFm02WTw.PYnQK', NULL, NULL, NULL, '2025-02-07 20:59:22', NULL, 3, 12, 6, 'محمد نبيل محمد القحطاني', '2025-02-07', 'الروضة الشمالية تعز', 'male'),
(3, 'mohamed7711115574@gmail.com', '0737636220', 1, NULL, '$2y$10$koeS6ycjC1MWFMqaXLbT5uO.CQC4W6Z092zXYCcqgUGiEfNNT0u.i', NULL, NULL, NULL, '2025-02-19 05:02:31', NULL, 9, 33, 6, 'sdhgfs', '2025-02-19', 'Tazi', 'male'),
(4, 'mohamed771114@gmail.com', '0772426722', 1, NULL, '$2y$10$WzWxy5MKTlEziE6ZtAN1pOQIjCPjPR7uQqPa7Owd4h1nUSL72txZ6', NULL, NULL, NULL, '2025-03-09 18:53:59', NULL, 8, 31, 6, 'RASHED A. FRHAN', '2025-03-05', '772426711', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `wilayas`
--

CREATE TABLE `wilayas` (
  `id` tinyint(4) NOT NULL,
  `name` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wilayas`
--

INSERT INTO `wilayas` (`id`, `name`) VALUES
(1, 'Eastern Province'),
(2, 'Makkah Province'),
(3, 'Riyadh Province'),
(4, 'Asir Province'),
(5, 'Madinah Province'),
(6, 'Qassim Province'),
(7, 'Tabuk Province'),
(8, 'Jazan Province'),
(9, 'Najran Province'),
(10, 'Northern Borders Province'),
(11, 'Al-Bahah Province'),
(12, 'Al-Jouf Province');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blood_groups`
--
ALTER TABLE `blood_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dairas`
--
ALTER TABLE `dairas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dairas_wilaya_id_foreign` (`wilaya_id`);

--
-- Indexes for table `donated_organs`
--
ALTER TABLE `donated_organs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organs_groups`
--
ALTER TABLE `organs_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organs_recipients`
--
ALTER TABLE `organs_recipients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organ_donors`
--
ALTER TABLE `organ_donors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `organ_donors_user_id_foreign` (`user_id`),
  ADD KEY `organ` (`organ`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`),
  ADD KEY `users_wilaya_id_foreign` (`wilaya_id`),
  ADD KEY `users_daira_id_foreign` (`daira_id`),
  ADD KEY `users_blood_group_id_foreign` (`blood_group_id`);

--
-- Indexes for table `wilayas`
--
ALTER TABLE `wilayas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blood_groups`
--
ALTER TABLE `blood_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `dairas`
--
ALTER TABLE `dairas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `donated_organs`
--
ALTER TABLE `donated_organs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `organs_groups`
--
ALTER TABLE `organs_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `organs_recipients`
--
ALTER TABLE `organs_recipients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `organ_donors`
--
ALTER TABLE `organ_donors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wilayas`
--
ALTER TABLE `wilayas`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dairas`
--
ALTER TABLE `dairas`
  ADD CONSTRAINT `dairas_wilaya_id_foreign` FOREIGN KEY (`wilaya_id`) REFERENCES `wilayas` (`id`);

--
-- Constraints for table `organ_donors`
--
ALTER TABLE `organ_donors`
  ADD CONSTRAINT `organ_donors_ibfk_1` FOREIGN KEY (`organ`) REFERENCES `organs_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `organ_donors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_blood_group_id_foreign` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`),
  ADD CONSTRAINT `users_daira_id_foreign` FOREIGN KEY (`daira_id`) REFERENCES `dairas` (`id`),
  ADD CONSTRAINT `users_wilaya_id_foreign` FOREIGN KEY (`wilaya_id`) REFERENCES `wilayas` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
