<div class="container">
    <div class="row justify-content-center">
        <div class="col-10 rounded-3 shadow p-5 position-relative bg-white searchBox">
            <h3 class="text-center mb-4">Search for Organ Donors in Your Area</h3>

            <form id="donorsSearchForm" action="donors" method="get"
                class="d-flex flex-column flex-xl-row gap-3" novalidate>
                <div class="w-100">
                    <select name="blood_group" id="bloodGroup" class="form-select form-select-lg">
                        <option selected hidden style="display:none" value="">Organ Type</option>
                        <option value="all">All</option>
                        <?php while ($row = $result_organs_groups->fetch_assoc()): ?>
        <option value="<?php echo $row['id'] ?>"><?php echo $row['organs_name'] ?></option>
          <?php endwhile; ?>

                    </select>

                    <div class="invalid-feedback">
                        Please select an organ.
                    </div>
                </div>

                <div class="w-100">
                <div class="invalid-feedback">
        Please select a province.
    </div>
    <select name="wilaya" id="wilayaSelect" class="form-select form-select-lg">
        <option selected hidden style="display:none" value="">province</option>
        <?php while ($row = $wilayaresulto->fetch_assoc()): ?>
            <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
        <?php endwhile; ?>
    </select>


</div>

<div class="w-100">
    <select name="daira" id="dairaSelect" class="form-select form-select-lg" disabled>
        <option selected hidden style="display:none" value="">Governorate</option>
    </select>

    <div class="invalid-feedback">
        Please select a Governorate.
    </div>
</div>

                <button class="btn btn-danger px-5 searchDonorsBtn" type="submit"><svg
                        xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor"
                        class="bi bi-search" viewBox="0 0 16 16">
                        <path
                            d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                    </svg></button>
            </form>
        </div>
    </div>
</div>
