<?php
// تضمين ملف التكوين
include('config.php');

// الحصول على ID Province من الاستعلام
$wilaya_id = isset($_POST['wilaya_id']) ? (int) $_POST['wilaya_id'] : 0;

// التحقق من أن Province موجودة
if ($wilaya_id > 0) {
    // استعلام SQL لجلب الدوائر المرتبطة بProvince المحددة
    $query = "SELECT * FROM dairas WHERE wilaya_id = $wilaya_id";
    $result = $conn->query($query);

    // التحقق من وجود نتائج
    if ($result->num_rows > 0) {
        // إرجاع الدوائر في تنسيق HTML
        while ($row = $result->fetch_assoc()) {
            echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
        }
    } else {
        echo '<option value="">لا توجد دوائر</option>';
    }
} else {
    echo '<option value="">الرجاء اختيار ولاية أولاً</option>';
}
?>
