<?php
if (!isset($_SESSION['user_id'])) {
    // إذا لم يكن المستخدم مسجلًا، يتم تحويله إلى صفحة تسجيل الدخول

    include("main_header.php");

}
else {
    // إذا كان المستخدم مسجلًا، يتم تضمين رأس الصفحة
    include("login_heder.php");
}

?>
