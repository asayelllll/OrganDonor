<?php
include 'config.php';

// استقبال القيم من الطلب مع ضمان النوع الصحيح
$organ_group = isset($_GET['organ_group']) ? intval($_GET['organ_group']) : 0;
$wilaya = isset($_GET['wilaya']) ? intval($_GET['wilaya']) : 0;
$daira = isset($_GET['daira']) ? intval($_GET['daira']) : 0;

// جلب معرف مجموعة الأعضاء من قاعدة البيانات
$organs_group_ID = 0;
if ($organ_group > 0) {
    $sql = "SELECT id FROM organs_groups WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $organ_group);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $organs_group_ID = $row['id'];
    }
    $stmt->close();
}

// بناء استعلام البحث عن المتبرعين
$query = "SELECT od.*, u.name, u.email, u.phone, u.readyToGive, 
                 w.name AS wilaya_name, d.name AS daira_name, og.organs_name 
          FROM organ_donors od
          INNER JOIN users u ON od.user_id = u.id
          LEFT JOIN wilayas w ON u.wilaya_id = w.id
          LEFT JOIN dairas d ON u.daira_id = d.id
          LEFT JOIN organs_groups og ON od.organ = og.id
          WHERE u.readyToGive = 1";

// إضافة الشرط فقط عند وجود قيمة صحيحة
$params = [];
$types = "";

if ($organs_group_ID > 0) {
    $query .= " AND od.organ = ?";
    $params[] = $organs_group_ID;
    $types .= "i";
}
if ($wilaya > 0) {
    $query .= " AND u.wilaya_id = ?";
    $params[] = $wilaya;
    $types .= "i";
}
if ($daira > 0) {
    $query .= " AND u.daira_id = ?";
    $params[] = $daira;
    $types .= "i";
}

// تنفيذ الاستعلام باستخدام `prepare` لحماية البيانات
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<div class='container mt-5'>";
    
    // عنوان وزر الطباعة
    echo "<div class='d-flex justify-content-between align-items-center mb-4'>";
    echo "<h2 class='text-danger fw-bold'>Organ Donors List</h2>";
    echo "<button onclick='printTable()' class='btn btn-danger px-4 py-2 rounded-pill shadow-sm'><i class='bi bi-printer'></i> Print</button>";
    echo "</div>";

    echo "<div class='table-responsive' id='printableTable'>";
    
    // تصميم الجدول الحديث
    echo "<table class='table table-hover table-bordered text-center shadow-lg rounded overflow-hidden'>";
    
    // رأس الجدول
    echo "<thead class='text-white' style='background: linear-gradient(45deg, #d9534f, #c9302c);'>";
    echo "<tr class='align-middle'>
            <th>#</th>
            <th>Donor Name</th>
            <th>Gender</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Province</th>
            <th>Governorate</th>
            <th>Blood Type</th>
            <th>Health Status</th>
            <th>Medical Conditions</th>
            <th>Organ Type</th>
          </tr>";
    echo "</thead>";
    
    // محتوى الجدول
    echo "<tbody>";
    $counter = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr class='align-middle' style='background-color: #fff; transition: 0.3s ease-in-out;'>";
        echo "<td class='fw-bold text-danger'>" . $counter++ . "</td>";
        echo "<td class='fw-bold'>" . htmlspecialchars($row['donor_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['donor_gender']) . "</td>";
        echo "<td class='text-primary fw-bold'>" . htmlspecialchars($row['email']) . "</td>";
        echo "<td class='fw-bold text-success'>" . htmlspecialchars($row['phone']) . "</td>";
        echo "<td>" . htmlspecialchars($row['wilaya_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['daira_name']) . "</td>";
        echo "<td class='fw-bold text-danger'>" . htmlspecialchars($row['blood']) . "</td>";
        echo "<td class='fw-bold text-warning'>" . htmlspecialchars($row['Health_status']) . "</td>";
        echo "<td class='text-muted'>" . htmlspecialchars($row['medical_conditions']) . "</td>";
        echo "<td class='fw-bold text-danger'>" . htmlspecialchars($row['organs_name']) . "</td>";
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
    echo "</div>"; // إغلاق `table-responsive`
    echo "</div>"; // إغلاق `container`
} else {
    echo "<p class='text-center text-danger fw-bold'>No donors found.</p>";
}



$stmt->close();
$conn->close();
?>
