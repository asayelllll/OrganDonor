

<?php

    require_once "config.php"; // الاتصال بقاعدة البيانات

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Connect to the database

        // Retrieve form data
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        if (empty($username) || empty($password)) {
            $_SESSION['error'] = "Please enter your email or phone number and password!";
            header("Location: login.php");
            exit();
        }

        // Check if the user exists (using email or phone number)
        $stmt = $conn->prepare("SELECT id, name, email, phone, password FROM users WHERE email = ? OR phone = ?");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $stmt->store_result();

        // If user exists
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $full_name, $email, $phone, $hashed_password);
            $stmt->fetch();

            // Verify password
            if (password_verify($password, $hashed_password)) {
                // Create session for the user
                $_SESSION['user_id']    = $id;
                $_SESSION['user_name']  = $full_name;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_phone'] = $phone;
                $_SESSION['success']    = "Login successful!";
                // حفظ اسم المستخدم في JavaScript لاستخدامه في localStorage
                echo "<script>
    localStorage.setItem('savedUsername', '" . addslashes($username) . "');
</script>";
                // Redirect to the home page
                header("Location: index.php");
                exit();
            } else {
                $_SESSION['error'] = "Incorrect password!";
            }
        } else {
            $_SESSION['error'] = "No account found with this email or phone number!";
        }

        $stmt->close();
        $conn->close();

        header("Location: login.php");
        exit();
    }
?>


<!doctype html>
<html lang="en" dir="ltr">
<head>
<title>Donate | Donor Login</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="description" content="Login">

<meta property="og:type" content="website">
<meta property="og:url" content="login">
<meta property="og:title" content="Donate | Donor Login">
<meta property="og:description" content="Login">
<meta property="og:image" content="imgs/passwordImage.jpg">
<meta property="og:locale" content="en_US">

<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="login">
<meta property="twitter:title" content="Donate | Donor Login">
<meta property="twitter:description" content="Login">
<meta property="twitter:image" content="imgs/passwordImage.jpg">





    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600&family=Nunito:wght@600;700&display=swap"
        rel="stylesheet">

            <link rel="preload" as="style" href="build/assets/bootstrap-rtl.6923a990.css" /><link rel="stylesheet" href="build/assets/bootstrap-rtl.6923a990.css" />
    <link rel="preload" as="style" href="build/assets/app.1fd5bbb5.css" />
    <link rel="stylesheet" href="build/assets/app.1fd5bbb5.css" />
        <link rel="preload" as="style" href="build/assets/loginPage.9c3ad3ad.css" />
        <link rel="stylesheet" href="build/assets/loginPage.9c3ad3ad.css" />
</head>

<body>
<?php
    include "header.php";
?>
<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['error']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); // حذف الرسالة بعد عرضها ?>
<?php endif; ?>

<?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['success']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success']); // حذف الرسالة بعد عرضها ?>
<?php endif; ?>
    <div class="signinForm m-4 p-4 rounded shadow">
        <form
            name="signInForm"
            action="login.php"
            method="post"
        >
            <input type="hidden" name="_token" value="FVAZX2EB18GLSIMqlV1mwJSAYCyvDLpaLztQVJVM">
                            <div class="alert alert-success text-center shadow-sm" role="alert">
                    We are very happy to have you back!
                </div>

                <div>
    <label for="id_username" class="form-label">Email or Phone Number</label>
    <input type="text" name="username" class="form-control" required id="id_username" placeholder="Email or Phone Number" />
</div>


            <div class="mt-3">
                <label for="id_password" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required id="id_password" placeholder="Password"/>
                <span class="form-text text-muted"></span>
                <small><a href="forgot-password" class="text-decoration-none text-danger">Forgot Password?</a></small>
            </div>

            <input id="submitBtn" class="btn btn-danger my-3 w-100" type="submit" value="Log In" />

            <span class="text-dark d-block text-center">Don't have an account? <a href="register.php" class="text-danger text-decoration-none">Create a new account</a></span>
        </form>
    </div>

    <?php

        include "footer.php";
    ?>


<script>
    // إخفاء التنبيهات بعد 5 ثوانٍ تلقائيًا
    setTimeout(function() {
        let alerts = document.querySelectorAll(".alert");
        alerts.forEach(alert => {
            alert.classList.remove("show");
            alert.classList.add("fade");
            setTimeout(() => alert.remove(), 500); // إزالة العنصر نهائيًا بعد الاختفاء
        });
    }, 5000);
</script>

<link rel="modulepreload" href="build/assets/app.375cedd6.js" /><script type="module" src="build/assets/app.375cedd6.js"></script>


<script>
    document.addEventListener("DOMContentLoaded", function() {
        // استرجاع اسم المستخدم المخزن وعرضه في الحقل
        let savedUsername = localStorage.getItem("savedUsername");
        if (savedUsername) {
            document.getElementById("id_username").value = savedUsername;
        }
    });
</script>


</body>

</html>
