
<?php
ob_start(); // يمنع إرسال أي بيانات للمتصفح قبل session_start()
session_start();

// إعدادات الاتصال بقاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'organdonation');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');

// إنشاء الاتصال بقاعدة البيانات
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// التحقق من الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}
?>