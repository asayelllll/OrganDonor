<?php
include '../config.php'; // ملف الاتصال بقاعدة البيانات

// استرجاع بيانات المستخدم
$user_id = $_SESSION['user_id'];
$sql = "SELECT 
            ro.*, 
            u.name AS user_name, 
            u.email AS user_email, 
            og.organs_name 
        FROM organ_donors ro
        INNER JOIN users u ON ro.user_id = u.id
        INNER JOIN organs_groups og ON ro.organ = bg.id
        WHERE ro.user_id = '$user_id'";



$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تاريخ التبرع بالدم</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600&family=Nunito:wght@600;700&display=swap"
        rel="stylesheet">


    <link
      rel="preload"
      as="style"
      href="../build/assets/bootstrap-rtl.6923a990.css"
    />
    <link rel="stylesheet" href="../build/assets/bootstrap-rtl.6923a990.css" />
    <link rel="preload" as="style" href="../build/assets/app.1fd5bbb5.css" />
    <link rel="stylesheet" href="../build/assets/app.1fd5bbb5.css" />
    <meta name="robots" content="noindex,nofollow" />
    <link
      rel="preload"
      as="style"
      href="../build/assets/userDashboard.2ee72fd6.css"
    />
    <link rel="stylesheet" href="../build/assets/userDashboard.2ee72fd6.css" />
  
    <script data-turbo-eval="false">
      jQuery.noConflict(true);
    </script>
  </head>
<body>

    <?php 
      include("header.php");
    ?>
    <div class="container mt-5">
        <h1 class="text-center mb-4">سجل تبرعات الاعضاء</h1>
        <table class="table table-bordered text-center">
            <thead class="table-primary">
                <tr>
                    <th>التاريخ</th>
                    <th>فصيلة الدم</th>
                    <th>الحالة</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['donation_date']; ?></td>
                        <td><?php echo $row['bloodGroup']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="btn btn-primary mt-3">العودة إلى لوحة التحكم</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  </body>
</html>
