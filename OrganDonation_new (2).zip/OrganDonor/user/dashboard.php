<?php

include '../config.php'; // Database connection file

// Retrieve user data
$user_id = $_SESSION['user_id'];

$query = "SELECT COUNT(*) as organ_donations FROM organ_donors WHERE user_id = '$user_id' ";
$result = mysqli_query($conn, $query);
$organ_data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600&family=Nunito:wght@600;700&display=swap"
        rel="stylesheet">

    <link
      rel="preload"
      as="style"
      href="../build/assets/bootstrap-rtl.6923a990.css"
    />
    <link rel="stylesheet" href="../build/assets/bootstrap-rtl.6923a990.css" />
    <link rel="preload" as="style" href="../build/assets/app.1fd5bbb5.css" />
    <link rel="stylesheet" href="../build/assets/app.1fd5bbb5.css" />
    <meta name="robots" content="noindex,nofollow" />
    <link
      rel="preload"
      as="style"
      href="../build/assets/userDashboard.2ee72fd6.css"
    />
    <link rel="stylesheet" href="../build/assets/userDashboard.2ee72fd6.css" />
  
    <script data-turbo-eval="false">
      jQuery.noConflict(true);
    </script>

  </head>

<body>
<?php 
  include("header.php");
?>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Welcome to the Dashboard</h1>
        <div class="row">
            
            <div class="col-md-6">
                <div class="card text-center">
                    <div class="card-body">
                        <h2 class="card-title">Number of Organ Donations</h2>
                        <p class="card-text display-4"><?php echo $organ_data['organ_donations']; ?></p>
                        <a href="organ_donations.php" class="btn btn-success">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  </body>
</html>
