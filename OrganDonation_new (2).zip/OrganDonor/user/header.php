<div class="modal fade" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="contactModalLabel">Contact Us</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h5 class="text-center">Thank you for your interest in contacting us. You can send us a message on our Facebook page.</h5>
                <div class="d-flex justify-content-center">
                    <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Flinatabara3&tabs&width=340&height=130&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=913151315819800" width="340" height="130" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">
                    <a href="https://m.me/linatabara3" target="_blank" class="text-white text-decoration-none d-flex">
                        <svg style="width: 16px; margin-inline-end: 7px; fill: white;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M256.55 8C116.52 8 8 110.34 8 248.57c0 72.3 29.71 134.78 78.07 177.94 8.35 7.51 6.63 11.86 8.05 58.23A19.92 19.92 0 0 0 122 502.31c52.91-23.3 53.59-25.14 62.56-22.7C337.85 521.8 504 423.7 504 248.57 504 110.34 396.59 8 256.55 8zm149.24 185.13l-73 115.57a37.37 37.37 0 0 1-53.91 9.93l-58.08-43.47a15 15 0 0 0-18 0l-78.37 59.44c-10.46 7.93-24.16-4.6-17.11-15.67l73-115.57a37.36 37.36 0 0 1 53.91-9.93l58.06 43.46a15 15 0 0 0 18 0l78.41-59.38c10.44-7.98 24.14 4.54 17.09 15.62z"/></svg> Messenger
                    </a>
                </button>
            </div>
        </div>
    </div>
</div>

<nav class="navbar navbar-expand-xl navbar-light bg-white shadow-sm sticky-lg-top">
    <div class="container">
        <a class="navbar-brand d-flex" href="../index.php">
            <span class="mx-2">|</span>
            <img src="  ../imgs/linatabara3Logo.png" alt="Linatabara3 Logo" height="40px">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggler"
            aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarToggler">

            <div class="languageSwitcher text-center">
                <a rel="alternate" hreflang="fr" href="  fr"
                    style="font-family: 'Nunito', sans-serif;"
                    class="px-3 mt-2 mt-lg-0 btn btn-danger btn-sm py-1"></a>
            </div>

            <ul class="navbar-nav mb-2 mb-lg-0 fw-bold">
            <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="  dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../index.php">Home</a>
                </li>

              
                <li class="nav-item">
                    <a class="nav-link " href="organ_donations.php">Organ Donation List</a>
                </li>
                <li class="nav-item">
                    <button type="button" class="nav-link btn btn-link" data-bs-toggle="modal"
                        data-bs-target="#contactModal">
                        Contact Us
                    </button>
                </li>
            </ul>

            <div class="dropdown d-flex justify-content-center">
                <button class="btn btn-danger dropdown-toggle" type="button" id="accountDropDownMenu"
                    data-bs-toggle="dropdown" aria-expanded="false">m@gmail.com</button>
                <ul class="dropdown-menu" aria-labelledby="accountDropDownMenu">
                    <li><a class="dropdown-item" href="dashboard.php">My Account</a></li>

                    <li>
                        <form action="logout.php" method="post">
                            <input type="hidden" name="_token" value="gpbZTNHPph8Kck8TLrGkHxKsH2xyT29NeFqlyIR2">                            
                            <input class="dropdown-item" type="submit" value="Logout">
                        </form>
                    </li>

                </ul>
            </div>
            
        </div>
    </div>
</nav>
