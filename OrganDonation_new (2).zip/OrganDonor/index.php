
<?php
    // تضمين ملف التكوين
    include 'config.php';

    // جلب فصائل الدم من قاعدة البيانات
    $query_blood_groups  = "SELECT * FROM blood_groups";
    $result_blood_groups = $conn->query($query_blood_groups);
    // جلب المناطق من قاعدة البيانات
    $wilayaqueryb  = "SELECT * FROM wilayas";
    $wilayaresultb = $conn->query($wilayaqueryb);
    $wilayaqueryo  = "SELECT * FROM wilayas";
    $wilayaresulto = $conn->query($wilayaqueryo);
        // جلب فصائل الدم من قاعدة البيانات
    $query_organs_groups  = "SELECT * FROM organs_groups";
    $result_organs_groups = $conn->query($query_organs_groups);
?>


<!doctype html>
<html lang="en" dir="ltr">
<head>
    <title>Donate | Connecting Organ Donors with Seekers</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="A platform that helps those in need of organs find donors in their area.">

    <meta property="og:type" content="website">
    <meta property="og:url" content="  ">
    <meta property="og:title" content="Donate | Connecting Organ Donors with Seekers">
    <meta property="og:description" content="An Algerian platform that helps those in need of organs find donors in their area.">
    <meta property="og:image" content="  imgs/vialsOfBlood.jpg">
    <meta property="og:locale" content="ar_DZ">

    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="  ">
    <meta property="twitter:title" content="Donate | Connecting Organ Donors with Seekers">
    <meta property="twitter:description" content="An Algerian platform that helps those in need of organs find donors in their area.">
    <meta property="twitter:image" content="  imgs/vialsOfBlood.jpg">


    <link rel="alternate" href="  " hreflang="ar" />


    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600&family=Nunito:wght@600;700&display=swap"
        rel="stylesheet">

            <link rel="preload" as="style" href="  build/assets/bootstrap-rtl.6923a990.css" /><link rel="stylesheet" href="  build/assets/bootstrap-rtl.6923a990.css" />
    <link rel="preload" as="style" href="  build/assets/app.1fd5bbb5.css" /><link rel="stylesheet" href="  build/assets/app.1fd5bbb5.css" />
        <meta name="google-site-verification" content="" />
    <link rel="preload" as="style" href="  build/assets/homeHero.a12ef423.css" /><link rel="preload" as="style" href="  build/assets/faq.8f4c48cc.css" /><link rel="preload" as="style" href="  build/assets/bloodDonationBenefits.91d90a87.css" /><link rel="preload" as="style" href="  build/assets/cta.914a397d.css" /><link rel="preload" as="style" href="  build/assets/stats.431c0330.css" /><link rel="stylesheet" href="  build/assets/homeHero.a12ef423.css" /><link rel="stylesheet" href="  build/assets/faq.8f4c48cc.css" /><link rel="stylesheet" href="  build/assets/bloodDonationBenefits.91d90a87.css" /><link rel="stylesheet" href="  build/assets/cta.914a397d.css" /><link rel="stylesheet" href="  build/assets/stats.431c0330.css" /><link rel='stylesheet' type='text/css' property='stylesheet' href='//127.0.0.1:8000/_debugbar/assets/stylesheets?v=1657495602&theme=auto' data-turbolinks-eval='false' data-turbo-eval='false'><script src='//127.0.0.1:8000/_debugbar/assets/javascript?v=1657495602' data-turbolinks-eval='false' data-turbo-eval='false'></script><script data-turbo-eval="false">jQuery.noConflict(true);</script>
<script> Sfdump = window.Sfdump || (function (doc) { var refStyle = doc.createElement('style'), rxEsc = /([.*+?^${}()|\[\]\/\\])/g, idRx = /\bsf-dump-\d+-ref[012]\w+\b/, keyHint = 0 <= navigator.platform.toUpperCase().indexOf('MAC') ? 'Cmd' : 'Ctrl', addEventListener = function (e, n, cb) { e.addEventListener(n, cb, false); }; refStyle.innerHTML = '.phpdebugbar pre.sf-dump .sf-dump-compact, .sf-dump-str-collapse .sf-dump-str-collapse, .sf-dump-str-expand .sf-dump-str-expand { display: none; }'; (doc.documentElement.firstElementChild || doc.documentElement.children[0]).appendChild(refStyle); refStyle = doc.createElement('style'); (doc.documentElement.firstElementChild || doc.documentElement.children[0]).appendChild(refStyle); if (!doc.addEventListener) { addEventListener = function (element, eventName, callback) { element.attachEvent('on' + eventName, function (e) { e.preventDefault = function () {e.returnValue = false;}; e.target = e.srcElement; callback(e); }); }; } function toggle(a, recursive) { var s = a.nextSibling || {}, oldClass = s.className, arrow, newClass; if (/\bsf-dump-compact\b/.test(oldClass)) { arrow = '▼'; newClass = 'sf-dump-expanded'; } else if (/\bsf-dump-expanded\b/.test(oldClass)) { arrow = '▶'; newClass = 'sf-dump-compact'; } else { return false; } if (doc.createEvent && s.dispatchEvent) { var event = doc.createEvent('Event'); event.initEvent('sf-dump-expanded' === newClass ? 'sfbeforedumpexpand' : 'sfbeforedumpcollapse', true, false); s.dispatchEvent(event); } a.lastChild.innerHTML = arrow; s.className = s.className.replace(/\bsf-dump-(compact|expanded)\b/, newClass); if (recursive) { try { a = s.querySelectorAll('.'+oldClass); for (s = 0; s < a.length; ++s) { if (-1 == a[s].className.indexOf(newClass)) { a[s].className = newClass; a[s].previousSibling.lastChild.innerHTML = arrow; } } } catch (e) { } } return true; }; function collapse(a, recursive) { var s = a.nextSibling || {}, oldClass = s.className; if (/\bsf-dump-expanded\b/.test(oldClass)) { toggle(a, recursive); return true; } return false; }; function expand(a, recursive) { var s = a.nextSibling || {}, oldClass = s.className; if (/\bsf-dump-compact\b/.test(oldClass)) { toggle(a, recursive); return true; } return false; }; function collapseAll(root) { var a = root.querySelector('a.sf-dump-toggle'); if (a) { collapse(a, true); expand(a); return true; } return false; } function reveal(node) { var previous, parents = []; while ((node = node.parentNode || {}) && (previous = node.previousSibling) && 'A' === previous.tagName) { parents.push(previous); } if (0 !== parents.length) { parents.forEach(function (parent) { expand(parent); }); return true; } return false; } function highlight(root, activeNode, nodes) { resetHighlightedNodes(root); Array.from(nodes||[]).forEach(function (node) { if (!/\bsf-dump-highlight\b/.test(node.className)) { node.className = node.className + ' sf-dump-highlight'; } }); if (!/\bsf-dump-highlight-active\b/.test(activeNode.className)) { activeNode.className = activeNode.className + ' sf-dump-highlight-active'; } } function resetHighlightedNodes(root) { Array.from(root.querySelectorAll('.sf-dump-str, .sf-dump-key, .sf-dump-public, .sf-dump-protected, .sf-dump-private')).forEach(function (strNode) { strNode.className = strNode.className.replace(/\bsf-dump-highlight\b/, ''); strNode.className = strNode.className.replace(/\bsf-dump-highlight-active\b/, ''); }); } return function (root, x) { root = doc.getElementById(root); var indentRx = new RegExp('^('+(root.getAttribute('data-indent-pad') || ' ').replace(rxEsc, '\\$1')+')+', 'm'), options = {"maxDepth":1,"maxStringLength":160,"fileLinkFormat":false}, elt = root.getElementsByTagName('A'), len = elt.length, i = 0, s, h, t = []; while (i < len) t.push(elt[i++]); for (i in x) { options[i] = x[i]; } function a(e, f) { addEventListener(root, e, function (e, n) { if ('A' == e.target.tagName) { f(e.target, e); } else if ('A' == e.target.parentNode.tagName) { f(e.target.parentNode, e); } else { n = /\bsf-dump-ellipsis\b/.test(e.target.className) ? e.target.parentNode : e.target; if ((n = n.nextElementSibling) && 'A' == n.tagName) { if (!/\bsf-dump-toggle\b/.test(n.className)) { n = n.nextElementSibling || n; } f(n, e, true); } } }); }; function isCtrlKey(e) { return e.ctrlKey || e.metaKey; } function xpathString(str) { var parts = str.match(/[^'"]+|['"]/g).map(function (part) { if ("'" == part) { return '"\'"'; } if ('"' == part) { return "'\"'"; } return "'" + part + "'"; }); return "concat(" + parts.join(",") + ", '')"; } function xpathHasClass(className) { return "contains(concat(' ', normalize-space(@class), ' '), ' " + className +" ')"; } addEventListener(root, 'mouseover', function (e) { if ('' != refStyle.innerHTML) { refStyle.innerHTML = ''; } }); a('mouseover', function (a, e, c) { if (c) { e.target.style.cursor = "pointer"; } else if (a = idRx.exec(a.className)) { try { refStyle.innerHTML = '.phpdebugbar pre.sf-dump .'+a[0]+'{background-color: #B729D9; color: #FFF !important; border-radius: 2px}'; } catch (e) { } } }); a('click', function (a, e, c) { if (/\bsf-dump-toggle\b/.test(a.className)) { e.preventDefault(); if (!toggle(a, isCtrlKey(e))) { var r = doc.getElementById(a.getAttribute('href').slice(1)), s = r.previousSibling, f = r.parentNode, t = a.parentNode; t.replaceChild(r, a); f.replaceChild(a, s); t.insertBefore(s, r); f = f.firstChild.nodeValue.match(indentRx); t = t.firstChild.nodeValue.match(indentRx); if (f && t && f[0] !== t[0]) { r.innerHTML = r.innerHTML.replace(new RegExp('^'+f[0].replace(rxEsc, '\\$1'), 'mg'), t[0]); } if (/\bsf-dump-compact\b/.test(r.className)) { toggle(s, isCtrlKey(e)); } } if (c) { } else if (doc.getSelection) { try { doc.getSelection().removeAllRanges(); } catch (e) { doc.getSelection().empty(); } } else { doc.selection.empty(); } } else if (/\bsf-dump-str-toggle\b/.test(a.className)) { e.preventDefault(); e = a.parentNode.parentNode; e.className = e.className.replace(/\bsf-dump-str-(expand|collapse)\b/, a.parentNode.className); } }); elt = root.getElementsByTagName('SAMP'); len = elt.length; i = 0; while (i < len) t.push(elt[i++]); len = t.length; for (i = 0; i < len; ++i) { elt = t[i]; if ('SAMP' == elt.tagName) { a = elt.previousSibling || {}; if ('A' != a.tagName) { a = doc.createElement('A'); a.className = 'sf-dump-ref'; elt.parentNode.insertBefore(a, elt); } else { a.innerHTML += ' '; } a.title = (a.title ? a.title+'\n[' : '[')+keyHint+'+click] Expand all children'; a.innerHTML += elt.className == 'sf-dump-compact' ? '<span>▶</span>' : '<span>▼</span>'; a.className += ' sf-dump-toggle'; x = 1; if ('sf-dump' != elt.parentNode.className) { x += elt.parentNode.getAttribute('data-depth')/1; } } else if (/\bsf-dump-ref\b/.test(elt.className) && (a = elt.getAttribute('href'))) { a = a.slice(1); elt.className += ' '+a; if (/[\[{]$/.test(elt.previousSibling.nodeValue)) { a = a != elt.nextSibling.id && doc.getElementById(a); try { s = a.nextSibling; elt.appendChild(a); s.parentNode.insertBefore(a, s); if (/^[@#]/.test(elt.innerHTML)) { elt.innerHTML += ' <span>▶</span>'; } else { elt.innerHTML = '<span>▶</span>'; elt.className = 'sf-dump-ref'; } elt.className += ' sf-dump-toggle'; } catch (e) { if ('&' == elt.innerHTML.charAt(0)) { elt.innerHTML = '…'; elt.className = 'sf-dump-ref'; } } } } } if (doc.evaluate && Array.from && root.children.length > 1) { root.setAttribute('tabindex', 0); SearchState = function () { this.nodes = []; this.idx = 0; }; SearchState.prototype = { next: function () { if (this.isEmpty()) { return this.current(); } this.idx = this.idx < (this.nodes.length - 1) ? this.idx + 1 : 0; return this.current(); }, previous: function () { if (this.isEmpty()) { return this.current(); } this.idx = this.idx > 0 ? this.idx - 1 : (this.nodes.length - 1); return this.current(); }, isEmpty: function () { return 0 === this.count(); }, current: function () { if (this.isEmpty()) { return null; } return this.nodes[this.idx]; }, reset: function () { this.nodes = []; this.idx = 0; }, count: function () { return this.nodes.length; }, }; function showCurrent(state) { var currentNode = state.current(), currentRect, searchRect; if (currentNode) { reveal(currentNode); highlight(root, currentNode, state.nodes); if ('scrollIntoView' in currentNode) { currentNode.scrollIntoView(true); currentRect = currentNode.getBoundingClientRect(); searchRect = search.getBoundingClientRect(); if (currentRect.top < (searchRect.top + searchRect.height)) { window.scrollBy(0, -(searchRect.top + searchRect.height + 5)); } } } counter.textContent = (state.isEmpty() ? 0 : state.idx + 1) + ' of ' + state.count(); } var search = doc.createElement('div'); search.className = 'sf-dump-search-wrapper sf-dump-search-hidden'; search.innerHTML = ' <input type="text" class="sf-dump-search-input"> <span class="sf-dump-search-count">0 of 0<\/span> <button type="button" class="sf-dump-search-input-previous" tabindex="-1"> <svg viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1683 1331l-166 165q-19 19-45 19t-45-19L896 965l-531 531q-19 19-45 19t-45-19l-166-165q-19-19-19-45.5t19-45.5l742-741q19-19 45-19t45 19l742 741q19 19 19 45.5t-19 45.5z"\/><\/svg> <\/button> <button type="button" class="sf-dump-search-input-next" tabindex="-1"> <svg viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1683 808l-742 741q-19 19-45 19t-45-19L109 808q-19-19-19-45.5t19-45.5l166-165q19-19 45-19t45 19l531 531 531-531q19-19 45-19t45 19l166 165q19 19 19 45.5t-19 45.5z"\/><\/svg> <\/button> '; root.insertBefore(search, root.firstChild); var state = new SearchState(); var searchInput = search.querySelector('.sf-dump-search-input'); var counter = search.querySelector('.sf-dump-search-count'); var searchInputTimer = 0; var previousSearchQuery = ''; addEventListener(searchInput, 'keyup', function (e) { var searchQuery = e.target.value; /* Don't perform anything if the pressed key didn't change the query */ if (searchQuery === previousSearchQuery) { return; } previousSearchQuery = searchQuery; clearTimeout(searchInputTimer); searchInputTimer = setTimeout(function () { state.reset(); collapseAll(root); resetHighlightedNodes(root); if ('' === searchQuery) { counter.textContent = '0 of 0'; return; } var classMatches = [ "sf-dump-str", "sf-dump-key", "sf-dump-public", "sf-dump-protected", "sf-dump-private", ].map(xpathHasClass).join(' or '); var xpathResult = doc.evaluate('.//span[' + classMatches + '][contains(translate(child::text(), ' + xpathString(searchQuery.toUpperCase()) + ', ' + xpathString(searchQuery.toLowerCase()) + '), ' + xpathString(searchQuery.toLowerCase()) + ')]', root, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null); while (node = xpathResult.iterateNext()) state.nodes.push(node); showCurrent(state); }, 400); }); Array.from(search.querySelectorAll('.sf-dump-search-input-next, .sf-dump-search-input-previous')).forEach(function (btn) { addEventListener(btn, 'click', function (e) { e.preventDefault(); -1 !== e.target.className.indexOf('next') ? state.next() : state.previous(); searchInput.focus(); collapseAll(root); showCurrent(state); }) }); addEventListener(root, 'keydown', function (e) { var isSearchActive = !/\bsf-dump-search-hidden\b/.test(search.className); if ((114 === e.keyCode && !isSearchActive) || (isCtrlKey(e) && 70 === e.keyCode)) { /* F3 or CMD/CTRL + F */ if (70 === e.keyCode && document.activeElement === searchInput) { /* * If CMD/CTRL + F is hit while having focus on search input, * the user probably meant to trigger browser search instead. * Let the browser execute its behavior: */ return; } e.preventDefault(); search.className = search.className.replace(/\bsf-dump-search-hidden\b/, ''); searchInput.focus(); } else if (isSearchActive) { if (27 === e.keyCode) { /* ESC key */ search.className += ' sf-dump-search-hidden'; e.preventDefault(); resetHighlightedNodes(root); searchInput.value = ''; } else if ( (isCtrlKey(e) && 71 === e.keyCode) /* CMD/CTRL + G */ || 13 === e.keyCode /* Enter */ || 114 === e.keyCode /* F3 */ ) { e.preventDefault(); e.shiftKey ? state.previous() : state.next(); collapseAll(root); showCurrent(state); } } }); } if (0 >= options.maxStringLength) { return; } try { elt = root.querySelectorAll('.sf-dump-str'); len = elt.length; i = 0; t = []; while (i < len) t.push(elt[i++]); len = t.length; for (i = 0; i < len; ++i) { elt = t[i]; s = elt.innerText || elt.textContent; x = s.length - options.maxStringLength; if (0 < x) { h = elt.innerHTML; elt[elt.innerText ? 'innerText' : 'textContent'] = s.substring(0, options.maxStringLength); elt.className += ' sf-dump-str-collapse'; elt.innerHTML = '<span class=sf-dump-str-collapse>'+h+'<a class="sf-dump-ref sf-dump-str-toggle" title="Collapse"> ◀</a></span>'+ '<span class=sf-dump-str-expand>'+elt.innerHTML+'<a class="sf-dump-ref sf-dump-str-toggle" title="'+x+' remaining characters"> ▶</a></span>'; } } } catch (e) { } }; })(document); </script><style> .phpdebugbar pre.sf-dump { display: block; white-space: pre; padding: 5px; overflow: initial !important; } .phpdebugbar pre.sf-dump:after { content: ""; visibility: hidden; display: block; height: 0; clear: both; } .phpdebugbar pre.sf-dump span { display: inline; } .phpdebugbar pre.sf-dump a { text-decoration: none; cursor: pointer; border: 0; outline: none; color: inherit; } .phpdebugbar pre.sf-dump img { max-width: 50em; max-height: 50em; margin: .5em 0 0 0; padding: 0; background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAAAAAA6mKC9AAAAHUlEQVQY02O8zAABilCaiQEN0EeA8QuUcX9g3QEAAjcC5piyhyEAAAAASUVORK5CYII=) #D3D3D3; } .phpdebugbar pre.sf-dump .sf-dump-ellipsis { display: inline-block; overflow: visible; text-overflow: ellipsis; max-width: 5em; white-space: nowrap; overflow: hidden; vertical-align: top; } .phpdebugbar pre.sf-dump .sf-dump-ellipsis+.sf-dump-ellipsis { max-width: none; } .phpdebugbar pre.sf-dump code { display:inline; padding:0; background:none; } .sf-dump-public.sf-dump-highlight, .sf-dump-protected.sf-dump-highlight, .sf-dump-private.sf-dump-highlight, .sf-dump-str.sf-dump-highlight, .sf-dump-key.sf-dump-highlight { background: rgba(111, 172, 204, 0.3); border: 1px solid #7DA0B1; border-radius: 3px; } .sf-dump-public.sf-dump-highlight-active, .sf-dump-protected.sf-dump-highlight-active, .sf-dump-private.sf-dump-highlight-active, .sf-dump-str.sf-dump-highlight-active, .sf-dump-key.sf-dump-highlight-active { background: rgba(253, 175, 0, 0.4); border: 1px solid #ffa500; border-radius: 3px; } .phpdebugbar pre.sf-dump .sf-dump-search-hidden { display: none !important; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper { font-size: 0; white-space: nowrap; margin-bottom: 5px; display: flex; position: -webkit-sticky; position: sticky; top: 5px; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > * { vertical-align: top; box-sizing: border-box; height: 21px; font-weight: normal; border-radius: 0; background: #FFF; color: #757575; border: 1px solid #BBB; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > input.sf-dump-search-input { padding: 3px; height: 21px; font-size: 12px; border-right: none; border-top-left-radius: 3px; border-bottom-left-radius: 3px; color: #000; min-width: 15px; width: 100%; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > .sf-dump-search-input-next, .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > .sf-dump-search-input-previous { background: #F2F2F2; outline: none; border-left: none; font-size: 0; line-height: 0; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > .sf-dump-search-input-next { border-top-right-radius: 3px; border-bottom-right-radius: 3px; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > .sf-dump-search-input-next > svg, .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > .sf-dump-search-input-previous > svg { pointer-events: none; width: 12px; height: 12px; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > .sf-dump-search-count { display: inline-block; padding: 0 5px; margin: 0; border-left: none; line-height: 21px; font-size: 12px; }.phpdebugbar pre.sf-dump, .phpdebugbar pre.sf-dump .sf-dump-default{word-wrap: break-word; white-space: pre-wrap; word-break: normal}.phpdebugbar pre.sf-dump .sf-dump-num{font-weight:bold; color:#1299DA}.phpdebugbar pre.sf-dump .sf-dump-const{font-weight:bold}.phpdebugbar pre.sf-dump .sf-dump-str{font-weight:bold; color:#3A9B26}.phpdebugbar pre.sf-dump .sf-dump-note{color:#1299DA}.phpdebugbar pre.sf-dump .sf-dump-ref{color:#7B7B7B}.phpdebugbar pre.sf-dump .sf-dump-public{color:#000000}.phpdebugbar pre.sf-dump .sf-dump-protected{color:#000000}.phpdebugbar pre.sf-dump .sf-dump-private{color:#000000}.phpdebugbar pre.sf-dump .sf-dump-meta{color:#B729D9}.phpdebugbar pre.sf-dump .sf-dump-key{color:#3A9B26}.phpdebugbar pre.sf-dump .sf-dump-index{color:#1299DA}.phpdebugbar pre.sf-dump .sf-dump-ellipsis{color:#A0A000}.phpdebugbar pre.sf-dump .sf-dump-ns{user-select:none;}.phpdebugbar pre.sf-dump .sf-dump-ellipsis-note{color:#1299DA}</style>
</head>

<body>
  <?php 
    include("header.php");
  ?>
  <div class="shadow-sm">
      <div class="container col-xxl-8 px-4 py-5 hero">
          <div class="row align-items-center g-5 mb-5" style="padding-bottom: 6px;">
              <div class="col-lg-6 mt-xl-0">
                  <h1 class="headline display-5 fw-bold lh-1 mb-3 text-center text-lg-start">
                      Your Organ   Donation Can Save Someone's Life!
                  </h1>
                  <p class="lead text-center text-lg-start">
                      Organ donation helps save millions of lives each year, as donating organs such as the kidneys, liver, and heart can give a new life to patients in need. Organ donation is a noble humanitarian act that contributes to improving the quality of life for patients suffering from serious health conditions, giving them a new chance to live a healthier life.
                  </p>
                  <div class="d-grid gap-2 d-md-flex justify-content-md-center justify-content-lg-start">
                    <?php
                    if(!isset($_SESSION['user_id'])){
                      ?>
                      
                    
                  <a href="register.php"
                          class="btn btn-danger btn-lg px-4 me-md-2 d-flex align-items-center justify-content-center">
                          Create an Account 
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                              class="bi bi-suit-heart-fill" viewBox="0 0 16 16">
                              <path
                                  d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z" />
                          </svg>
                      </a>
                      <?php
                    }
                    ?>
                      <a href="organ_donors.php" class="btn btn-outline-danger btn-lg px-4">Need an Organ</a>
                  </div>
              </div>
              <div class="col-12 col-lg-6 d-flex flex-column align-items-center mb-5">
                  <img src="imgs/humanorgans.svg" class="d-block mx-lg-auto img-fluid" width="700" height="500">
              </div>
          </div>
      </div>
  </div>

  <section style="    padding-top: 90px;">
  <?php
  include("organ_donor_search.php");
  ?>
  </section>
  <?php 
  include("organDonationBenefitsSectino.php");
  ?>





  <section id="faq" class="faq">

      <div class="container" data-aos="fade-up">

          <header class="section-header">
              <h1 class="text-danger">Some Useful Information About Organ Donation</h1>
          </header>

          <div class="row">
              <div class="col-lg-6">
                  <!-- F.A.Q List 1-->
                  <div class="accordion accordion-flush" id="faqlist1">
                      <div class="accordion-item">
                          <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                                  Conditions That Make You Eligible for Organ Donation
                              </button>
                          </h2>
                          <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                              <div class="accordion-body">
                                  <ul>
                                      <li>- The donor must be in good health.</li>
                                      <li>- Living individuals can donate certain organs such as kidneys and liver.</li>
                                      <li>- Posthumous donation requires prior consent from the donor or their family.</li>
                                      <li>- Certain chronic diseases may prevent donation.</li>
                                  </ul>
                              </div>
                          </div>
                      </div>

                      <div class="accordion-item">
                          <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                                  What to Do Before Donating Organs
                              </button>
                          </h2>
                          <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                              <div class="accordion-body">
                                  <ul>
                                      <li>- Undergo the necessary medical examinations.</li>
                                      <li>- Ensure you have registered your organ donation preference.</li>
                                      <li>- Discuss the matter with your family to confirm your decision.</li>
                                  </ul>
                              </div>
                          </div>
                      </div>

                      <div class="accordion-item">
                          <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                                  Factors That Prevent You from Donating Organs
                              </button>
                          </h2>
                          <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                              <div class="accordion-body">
                                  <ul>
                                      <li>- Having serious illnesses such as cancer or AIDS.</li>
                                      <li>- Presence of infectious diseases affecting the organs.</li>
                                      <li>- Health issues that prevent doctors from safely using the organs.</li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>

              <div class="col-lg-6">
                  <!-- F.A.Q List 2-->
                  <div class="accordion accordion-flush" id="faqlist2">
                      <div class="accordion-item">
                          <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2-content-1">
                                  How Long Does the Donation Process Take?
                              </button>
                          </h2>
                          <div id="faq2-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist2">
                              <div class="accordion-body">
                                  The duration of the procedure depends on the type of organ being donated and the recipient’s condition. For solid organs such as the kidney or liver, the process may take a few hours.
                              </div>
                          </div>
                      </div>

                      <div class="accordion-item">
                          <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2-content-2">
                                  Recommendations for Post-Donation Recovery
                              </button>
                          </h2>
                          <div id="faq2-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist2">
                              <div class="accordion-body">
                                  <ul>
                                      <li>- Follow the doctor's instructions carefully.</li>
                                      <li>- Get adequate rest and maintain good nutrition.</li>
                                      <li>- Have regular follow-ups with doctors to ensure full recovery.</li>
                                  </ul>
                              </div>
                          </div>
                      </div>

                      <div class="accordion-item">
                          <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2-content-3">
                                  Why Should I Become an Organ Donor?
                              </button>
                          </h2>
                          <div id="faq2-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist2">
                              <div class="accordion-body">
                                  <ul>
                                      <li>- Organ donation can save another person’s life.</li>
                                      <li>- It gives hope to individuals suffering from severe illnesses.</li>
                                      <li>- It helps improve the quality of life for patients in need.</li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>
  <section class="cta py-5 my-5 bg-dark">
    <div class="container d-flex flex-column align-items-center">
      <p class="text-white fs-2 text-center">Help Us Save Lives Through Organ Donation</p>
      <p class="text-white text-center fs-5">The best way to help is by registering as an organ donor, and if you can't do that, you can always help by raising awareness and sharing this site on social media.</p>
      <p class="text-white fs-3">Share the site on:</p>
    </div>


      <div class="shareBtns container d-flex flex-column flex-sm-row flex-wrap align-items-center justify-content-center">

          <a href="https://www.facebook.com/sharer/sharer.php?u=http://localhost" class="fbShare btn d-flex align-items-center justify-content-center" target="_blank" rel="nofollow">
              <svg class="fa-brands fa-facebook" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"/></svg>
              <span class="ms-2">Facebook</span>
          </a>

          <a href="https://www.facebook.com/dialog/send?link=http://localhost&app_id=194134865891187&redirect_uri=http://localhost" class="messengerShare btn d-flex align-items-center justify-content-center my-3 my-lg-0 mx-sm-3" target="_blank" rel="nofollow">
              <svg class="fa-brands fa-facebook-messenger" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M256.55 8C116.52 8 8 110.34 8 248.57c0 72.3 29.71 134.78 78.07 177.94 8.35 7.51 6.63 11.86 8.05 58.23A19.92 19.92 0 0 0 122 502.31c52.91-23.3 53.59-25.14 62.56-22.7C337.85 521.8 504 423.7 504 248.57 504 110.34 396.59 8 256.55 8zm149.24 185.13l-73 115.57a37.37 37.37 0 0 1-53.91 9.93l-58.08-43.47a15 15 0 0 0-18 0l-78.37 59.44c-10.46 7.93-24.16-4.6-17.11-15.67l73-115.57a37.36 37.36 0 0 1 53.91-9.93l58.06 43.46a15 15 0 0 0 18 0l78.41-59.38c10.44-7.98 24.14 4.54 17.09 15.62z"/></svg>
              <span class="ms-2">Messenger</span>
          </a>

          <a href="https://web.whatsapp.com/send?text=http://localhost" class="whatsappShare btn d-flex align-items-center justify-content-center" target="_blank" rel="nofollow">
              <svg class="fa-brands fa-whatsapp" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/></svg>
              <span class="ms-2">Whatsapp</span>
          </a>

      </div>

  </section>
<?php
    include "Organ_Donor_Statistics.php";
?>



<?php 
  include("footer.php");
?>


<script>
    // عند تغيير اختيار Province
    document.getElementById('wilayaSelect').addEventListener('change', function() {
        var wilayaId = this.value; // الحصول على قيمة Province المحددة
        var dairaSelect = document.getElementById('dairaSelect');

        // تمكين قائمة الدوائر بعد اختيار Province
        dairaSelect.disabled = false;

        // إرسال طلب AJAX للحصول على الدوائر بناءً على Province
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_dairas.php', true);  // هنا يجب أن يكون الملف الذي يحتوي على منطق جلب الدوائر
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status == 200) {
                dairaSelect.innerHTML = '<option selected hidden style="display:none" value="">Governorate</option>' + xhr.responseText;
            }
        };
        xhr.send('wilaya_id=' + wilayaId); // إرسال ID Province إلى الملف
    });


</script>




<link rel="modulepreload" href="build/assets/app.375cedd6.js" /><script type="module" src="build/assets/app.375cedd6.js"></script>        <link rel="modulepreload" href="build/assets/donorsSearchFormValidation.0972e794.js" /><link rel="modulepreload" href="build/assets/gettingDairas.549e3cbc.js" />
<link rel="modulepreload" href="build/assets/tsPracticles.05139906.js" />
<link rel="modulepreload" href="build/assets/tsPracticlesEngine.76e32d40.js" />
<script type="module" src="build/assets/donorsSearchFormValidation.0972e794.js"></script><script type="module" src="build/assets/gettingDairas.549e3cbc.js">

</script>
<script type="module" src="build/assets/tsPracticles.05139906.js">

</script>
<script type="module" src="build/assets/tsPracticlesEngine.76e32d40.js">

</script>


</body>

</html>