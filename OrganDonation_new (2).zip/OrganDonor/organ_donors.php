<?php
    // تضمين ملف التكوين
    include 'config.php';
    $organ_group = isset($_GET['organ_group']) ? intval($_GET['organ_group']) : '';

    // جلب فصائل الدم من قاعدة البيانات
    $query_blood_groups  = "SELECT * FROM blood_groups";
    $result_blood_groups = $conn->query($query_blood_groups);
    // جلب المناطق من قاعدة البيانات
    $wilayaqueryb  = "SELECT * FROM wilayas";
    $wilayaresultb = $conn->query($wilayaqueryb);
    $wilayaqueryo  = "SELECT * FROM wilayas";
    $wilayaresulto = $conn->query($wilayaqueryo);
        // جلب فصائل الدم من قاعدة البيانات
    $query_organs_groups  = "SELECT * FROM organs_groups";
    $result_organs_groups = $conn->query($query_organs_groups);


    $sql = "SELECT og.id, og.organs_name, COUNT(od.id) AS total_donors 
        FROM organs_groups og
        LEFT JOIN organ_donors od ON og.id = od.organ
        GROUP BY og.id, og.organs_name";

      $organsGroup_result = $conn->query($sql);

      // تحويل البيانات إلى مصفوفة لتسهيل الوصول إليها
      $organsStats = [];
      while ($row = $organsGroup_result->fetch_assoc()) {
          $organsStats[$row['id']] = $row['total_donors'];
      }


      $organsGroups = [
        1 => "Heart",
        2 => "Liver",
        3 => "Kidneys",
        4 => "Lungs",
        5 => "Pancreas",
        6 => "Intestines",
        7 => "Cornea",
        8 => "Skin",
        9 => "Bones",
        10 => "Blood Vessels",
    ];
?>

<!doctype html>
<html lang="en" dir="ltr">
<head>
    <title>لنتبرع | قائمة المتبرعين بالاعضاء</title>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="البحث عن المتبرعين بالاعضاء في منطقتك.">


    <meta property="og:type" content="website">
    <meta property="og:url" content=" donors">
    <meta property="og:title" content="لنتبرع | قائمة المتبرعين بالاعضاء">
    <meta property="og:description" content="البحث عن المتبرعين بالاعضاء في منطقتك.">
    <meta property="og:image" content=" imgs/vialsOfBlood.jpg">
    <meta property="og:locale" content="ar_DZ">


    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content=" donors">
    <meta property="twitter:title" content="لنتبرع | قائمة المتبرعين بالاعضاء">
    <meta property="twitter:description" content="البحث عن المتبرعين بالاعضاء في منطقتك.">
    <meta property="twitter:image" content=" imgs/vialsOfBlood.jpg">
    <style>
      .table {
    border-radius: 10px;
    overflow: hidden;
}

.table thead {
    background: linear-gradient(45deg, #d9534f, #c9302c);
}

.table th {
    padding: 12px;
    text-transform: uppercase;
}

.table td {
    padding: 12px;
    font-size: 14px;
}

.table-hover tbody tr:hover {
    background-color: rgba(220, 53, 69, 0.1);
    transform: scale(1.02);
    transition: 0.3s ease-in-out;
}

.btn-danger {
    background-color: #d9534f;
    border-color: #c9302c;
}

.btn-danger:hover {
    background-color: #c9302c;
    border-color: #ac2925;
}

    </style>

    <link rel="alternate" href=" donors" hreflang="ar" />
    <link rel="alternate" href=" fr/donors" hreflang="fr" />

    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600&family=Nunito:wght@600;700&display=swap"
        rel="stylesheet">

            <link rel="preload" as="style" href=" build/assets/bootstrap-rtl.6923a990.css" /><link rel="stylesheet" href=" build/assets/bootstrap-rtl.6923a990.css" />
    <link rel="preload" as="style" href=" build/assets/app.1fd5bbb5.css" /><link rel="stylesheet" href=" build/assets/app.1fd5bbb5.css" />
            <link rel="preload" as="style" href=" build/assets/donorsPage.2c278c8b.css" /><link rel="preload" as="style" href=" build/assets/stats.431c0330.css" /><link rel="stylesheet" href=" build/assets/donorsPage.2c278c8b.css" /><link rel="stylesheet" href=" build/assets/stats.431c0330.css" />
            <script data-turbo-eval="false">jQuery.noConflict(true);</script>

</head>


<body>

<?php
    include "header.php";
?>


<div class="separator"> </div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-10 rounded-3 shadow p-5 position-relative bg-white searchBox">
            <h3 class="text-center mb-4">Search for Organ Donors in Your Area</h3>

            <form id="donorsSearchForm" action="donors" method="get"
                class="d-flex flex-column flex-xl-row gap-3" novalidate>
                <div class="w-100">
                    <select name="organsGroup" id="organsGroup" class="form-select form-select-lg">
                        <option selected hidden style="display:none" value="">Select Organ Type</option>

                        <?php while ($row = $result_organs_groups->fetch_assoc()): ?>
                            <option value="<?php echo $row['id'] ?>"><?php echo $row['organs_name'] ?></option>
                        <?php endwhile; ?>

                    </select>

                    <div class="invalid-feedback">
                        Please select a  type.
                    </div>
                </div>

                <div class="w-100">
                    <select name="wilaya" id="wilayaSelect" class="form-select form-select-lg">
                        <option selected hidden style="display:none" value="">Select Region</option>
                        <?php while ($row = $wilayaresultb->fetch_assoc()): ?>
                            <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                        <?php endwhile; ?>
                    </select>

                    <div class="invalid-feedback">
                        Please select a region.
                    </div>
                </div>

                <div class="w-100">
                    <select name="daira" id="dairaSelect" class="form-select form-select-lg" disabled>
                        <option selected hidden style="display:none" value="">Select Province</option>
                    </select>

                    <div class="invalid-feedback">
                        Please select a province.
                    </div>
                </div>

                <button class="btn btn-danger px-5 searchDonorsBtn" type="submit">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor"
                        class="bi bi-search" viewBox="0 0 16 16">
                        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                    </svg>
                </button>
            </form>
        </div>
    </div>
</div>


    <div class="searchResult container d-flex flex-wrap gap-4 justify-content-center">


                            


    </div>


    <section class="stats py-5 container">

    <h2 class="text-danger fs-1 text-center mb-4">Organ Donor Statistics</h2>

    <div class="d-flex flex-wrap align-items-center justify-content-center">

    <?php foreach ($organsGroups as $id => $type): ?>
      <a href="organ_donors.php?orgen_group=<?php echo urlencode($id); ?>" 
        class="statCard d-flex justify-content-center align-items-center mb-4 mx-2 shadow-lg text-decoration-none">
          <span class="bloodGroup text-danger"><?php echo $type; ?></span>
          <span class='statNumber shadow bg-danger fs-5 text-white py-2 px-3'><?php echo isset($organsStats[$id]) ? $organsStats[$id] : 0; ?></span>
      </a>
    <?php endforeach; ?>

    </div>
    <div class="d-flex flex-wrap align-items-center justify-content-center mt-4">
        <a href="organ_donor_register.php"
    class="btn btn-danger btn-lg px-4 me-md-2 d-flex align-items-center justify-content-center">
    Register as a Donor <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
        class="bi bi-suit-heart-fill" viewBox="0 0 16 16">
        <path
            d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z" />
    </svg></a>
    </div>

    </section>



<?php 
  include("footer.php");
?>


<link rel="modulepreload" href="build/assets/app.375cedd6.js" />
<script type="module" src="build/assets/app.375cedd6.js">

</script>
   <link rel="modulepreload" href="build/assets/donorsPage.d72a0547.js" />
   <link rel="modulepreload" href="build/assets/donorsSearchFormValidation.0972e794.js" />
   <link rel="modulepreload" href="build/assets/gettingDairas.549e3cbc.js" />
   <script type="module" src="build/assets/donorsPage.d72a0547.js">

   </script><script type="module" src="build/assets/donorsSearchFormValidation.0972e794.js">

   </script><script type="module" src="build/assets/gettingDairas.549e3cbc.js"></script>
<script>
    // عند تغيير اختيار Province
    document.getElementById('wilayaSelect').addEventListener('change', function() {
        var wilayaId = this.value; // الحصول على قيمة Province المحددة
        var dairaSelect = document.getElementById('dairaSelect');

        // تمكين قائمة الدوائر بعد اختيار Province
        dairaSelect.disabled = false;

        // إرسال طلب AJAX للحصول على الدوائر بناءً على Province
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_dairas.php', true);  // هنا يجب أن يكون الملف الذي يحتوي على منطق جلب الدوائر
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status == 200) {
                dairaSelect.innerHTML = '<option selected hidden style="display:none" value="">Governorate</option>' + xhr.responseText;
            }
        };
        xhr.send('wilaya_id=' + wilayaId); // إرسال ID Province إلى الملف
    });


</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
  let organsGroupsFromUrl = "<?php echo $organ_group; ?>";
    if (organsGroupsFromUrl) {
        $("#organsGroup").val(organsGroupsFromUrl);
        fetchDonors();
    }
    
    // إرسال طلب البحث عند تغيير الخيارات في البحث
    $("#donorsSearchForm").on("submit", function(e) {
        e.preventDefault();
        fetchDonors();
    });


    $(".statCard").on("click", function (e) {
    e.preventDefault();

    let hrefValue = $(this).attr("href");
    let urlParams = new URLSearchParams(hrefValue.split("?")[1]);
    let organsGroups = urlParams.get("orgen_group");

    if (!organsGroups) {
        console.error("لم يتم العثور على المجموعة في الرابط.");
        return;
    }

    console.log("المجموعة المختارة:", organsGroups); // لمراقبة القيمة المختارة

    let selectElement = $("#organsGroup");

    if (selectElement.find(`option[value='${organsGroups}']`).length) {
        selectElement.val(organsGroups).trigger("change");
    } else {
        selectElement.append(new Option(organsGroups, organsGroups, true, true)).trigger("change");
    }

    fetchDonors();
});

function fetchDonors() {
    let organsGroups = parseInt($("#organsGroup").val()) || 0;
    let wilaya = parseInt($("#wilayaSelect").val()) || 0;
    let daira = parseInt($("#dairaSelect").val()) || 0;

    $.ajax({
        url: "fetch_organ.php",
        type: "GET",
        data: { organ_group: organsGroups, wilaya: wilaya, daira: daira },
        beforeSend: function() {
            $(".searchResult").html("<p class='text-center'>جاري تحميل البيانات...</p>");
        },
        success: function(response) {
            $(".searchResult").html(response);
        }
    });
}
});





</script>
<script>
function printTable() {
    var printContents = document.getElementById("printableTable").innerHTML;
    var originalContents = document.body.innerHTML;

    var printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write(`
        <html>
        <head>
            <title>Print Donors List</title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
            <style>
                body { font-family: 'Arial', sans-serif; padding: 20px; }
                .table { border-collapse: collapse; width: 100%; border-radius: 10px; overflow: hidden; }
                .table, .table th, .table td { border: 1px solid #ddd; padding: 12px; }
                .table th { background: linear-gradient(45deg, #d9534f, #c9302c); color: white; text-transform: uppercase; }
                .table-hover tbody tr:hover { background-color: rgba(220, 53, 69, 0.1); transform: scale(1.02); transition: 0.3s ease-in-out; }
                h2 { color: #dc3545; text-align: center; margin-bottom: 20px; }
                .text-center { text-align: center; }
            </style>
        </head>
        <body>
            <h2>Organ Donors List</h2>
            ${printContents}
        </body>
        </html>
    `);
    
    printWindow.document.close();
    printWindow.print();
}
</script>



</body>

</html>
