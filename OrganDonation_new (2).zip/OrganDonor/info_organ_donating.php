<section id="faq" class="faq">

    <div class="container" data-aos="fade-up">

        <header class="section-header">
            <h1 class="text-danger">بعض المعلومات المفيدة عن التبرع بالدم</h1>
        </header>

        <div class="row">
            <div class="col-lg-6">
                <!-- F.A.Q List 1-->
                <div class="accordion accordion-flush" id="faqlist1">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                                الشروط التي تجعلك مؤهلاً للتبرع بالدم
                            </button>
                        </h2>
                        <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                            <div class="accordion-body">
                                <ul>
                                    <li>- يجب ألا يقل عمرك عن 17 عامًا.</li>
                                    <li>- يجب أن يكون وزنك 50 كجم أو أكثر.</li>
                                    <li>- يجب أن تكون نسبة الهيموجلوبين مناسبة للتبرع.</li>
                                    <li>- النساء الحوامل غير مؤهلات للتبرع ، انتظري 6 أسابيع بعد الولادة.</li>
                                    <li>- أن يكون المتبرع خالياً من بعض الأمراض التي تمنع التبرع.</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                                ما يجب فعله قبل التبرع
                            </button>
                        </h2>
                        <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                            <div class="accordion-body">
                                <ul>
                                    <li>- احصل على قسط كافٍ من النوم ، 5 ساعات على الأقل.</li>
                                    <li>- تناول وجبة قبل التبرع.</li>
                                    <li>- إحضار بطاقة الهوية.</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                                أشياع تمنعك من التبرع
                            </button>
                        </h2>
                        <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                            <div class="accordion-body">
                                <ul>
                                    <li>- تبرعت خلال الأشهر الثلاثة الماضية.</li>
                                    <li>- خضعت لأي عملية جراحية حديثا.</li>
                                    <li>- تعاني من أحد الأمراض التالية: ضغط الدم، السكري، الملاريا لمدة عامين على الأقل، الفشل الكلوي، تضخم الكبد، أمراض الصدر، الحمى الروماتيزمية، أمراض الغدة الدرقية، النزيف الوراثي.</li>
                                    <li>- الحوامل غير مؤهلين للتبرع ، انتظري 6 أسابيع بعد الولادة.</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="col-lg-6">

                <!-- F.A.Q List 2-->
                <div class="accordion accordion-flush" id="faqlist2">

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2-content-1">
                                كم من الوقت تستغرق عملية التبرع ؟
                            </button>
                        </h2>
                        <div id="faq2-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist2">
                            <div class="accordion-body">
                                في العادة، 20 دقيقة. الفترة التي يجب فصلها بين كل تبرع والآخر لنفس الشخص هي 3 أشهر لأنها الفترة المثالية لتكاثر خلايا الدم.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2-content-2">
                                بعض التوصيات لما بعد عملية التبرع
                            </button>
                        </h2>
                        <div id="faq2-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist2">
                            <div class="accordion-body">
                                <ul>
                                    <li>- إسترح لمدة 10 دقائق.</li>
                                    <li>- لا تبذل مجهودًا بدنيًا خلال ساعتين من بعد التبرع.</li>
                                    <li>- إشرب أكبر كمية ممكنة من السوائل.</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2-content-3">
                                لماذا يجب أن أكون متبرعا بالدم ؟
                            </button>
                        </h2>
                        <div id="faq2-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist2">
                            <div class="accordion-body">
                                <ul>
                                    <li>- كل ثلاث ثوان شخص ما في العالم يحتاج إلى دم.</li>
                                    <li>- تبرعك الواحد يمكن أن ينقذ 3 أشخاص.</li>
                                    <li>- عملية التبرع بالدم تعيد الحيوية والنشاط للجسم من خلال تجديد خلايا الدم.</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>

    </div>

</section>