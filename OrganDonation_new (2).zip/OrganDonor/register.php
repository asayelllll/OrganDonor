<?php

    require_once "config.php"; // استدعاء ملف الاتصال بقاعدة البيانات

    // جلب فصائل الدم من قاعدة البيانات
    $query_blood_groups  = "SELECT * FROM blood_groups";
    $result_blood_groups = $conn->query($query_blood_groups);
    // جلب المناطق من قاعدة البيانات
    $wilayaquery  = "SELECT * FROM wilayas";
    $wilayaresult = $conn->query($wilayaquery);

?>




<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $full_name = trim($_POST['full_name']);
    $date_of_birth = $_POST['date_of_birth'];
    $gender = $_POST['gender'];
    $address = trim($_POST['address']);
    $blood_group = $_POST['blood_group'];
    $wilaya = $_POST['wilaya'];
    $daira = $_POST['daira'];
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $password_confirmation = $_POST['password_confirmation'];

    if (empty($full_name) || empty($date_of_birth) || empty($gender) || empty($address) ||
    empty($blood_group) || empty($wilaya) || empty($daira) || empty($phone) || 
    empty($email) || empty($password) || empty($password_confirmation)) {
    $_SESSION['error'] = "All fields are required!";
    header("Location: register.php");
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error'] = "Invalid email address!";
    header("Location: register.php");
    exit();
}

if ($password !== $password_confirmation) {
    $_SESSION['error'] = "Passwords do not match!";
    header("Location: register.php");
    exit();
}

if (strlen($password) < 8) {
    $_SESSION['error'] = "Password must be at least 8 characters long!";
    header("Location: register.php");
    exit();
}
    // Hash password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
// Check if email is already in use
$check_email = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check_email->bind_param("s", $email);
$check_email->execute();
$check_email->store_result();

if ($check_email->num_rows > 0) {
    $_SESSION['error'] = "This email is already registered!";
    header("Location: register.php");
    exit();
}
$check_email->close();

// Insert user into database
$stmt = $conn->prepare("INSERT INTO users (name, date_birthday, gender, address, blood_group_id, wilaya_id, daira_id, phone, email, password, created_at) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("ssssssssss", $full_name, $date_of_birth, $gender, $address, $blood_group, $wilaya, $daira, $phone, $email, $hashed_password);

if ($stmt->execute()) {
    $_SESSION['success'] = "Registration successful! You can now log in.";
    header("Location: login.php");
} else {
    $_SESSION['error'] = "An error occurred during registration. Please try again.";
    header("Location: register.php");
}


    $stmt->close();
    $conn->close();
}
?>



<!doctype html>
<html lang="en" >
<head>
  <title>Let's Donate | Register as a Donor</title>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="Register as a donor">

  <meta property="og:type" content="website">
  <meta property="og:url" content="register">
  <meta property="og:title" content="Let's Donate | Register as a Donor">
  <meta property="og:description" content="Register as a donor">
  <meta property="og:image" content="imgs/vialsOfBlood.jpg">
  <meta property="og:locale" content="en_US">

  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:url" content="register">
  <meta property="twitter:title" content="Let's Donate | Register as a Donor">
  <meta property="twitter:description" content="Register as a donor">
  <meta property="twitter:image" content="imgs/vialsOfBlood.jpg">


    <link rel="alternate" href=" register" hreflang="ar" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600&family=Nunito:wght@600;700&display=swap"
        rel="stylesheet">


            <link rel="stylesheet" href=" build/assets/bootstrap-rtl.6923a990.css" />

    <link rel="stylesheet" href=" css/app.css" />
        <link rel="stylesheet"  href=" css/registerPage.css" />
        <script src="js/registerPage.js"></script>

        <script data-turbo-eval="false">jQuery.noConflict(true);</script>

</head>

<body>

<?php
    include "header.php";
?>
<?php if (isset($_SESSION['error'])): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<div class="formFieldsWrapper m-4">

<form name="signUpForm" class="needs-validation" action="register.php" method="post" novalidate>
    <input type="hidden" name="_token" value="FVAZX2EB18GLSIMqlV1mwJSAYCyvDLpaLztQVJVM">
    
    <div class="form-group">
        <label for="full_name" class="form-label mt-2">Full Name</label>
        <input type="text" class="form-control" name="full_name" id="full_name" required>
    </div>

    <div class="form-group">
        <label for="date_of_birth" class="form-label mt-2">Date of Birth</label>
        <input type="date" class="form-control" name="date_of_birth" id="date_of_birth" required>
    </div>

    <div class="form-group">
        <label class="form-label mt-2">Gender</label>
        <div>
            <input type="radio" name="gender" value="male" required> Male
            <input type="radio" name="gender" value="female" required> Female
        </div>
    </div>

    <div class="form-group">
        <label for="address" class="form-label mt-2">Residential Address</label>
        <input type="text" class="form-control" name="address" id="address" required>
    </div>

    <div>
        <label for="id_blood_group" class="form-label mt-2">Blood Type</label>
        <select data-validator-func="bloodGroupValidator" name="blood_group" class="form-select" id="id_blood_group">
            <option selected hidden style="display:none" value="">Blood Type</option>
            <?php while ($row = $result_blood_groups->fetch_assoc()): ?>
                <option value="<?php echo $row['id'] ?>"><?php echo $row['bloodGroup'] ?></option>
            <?php endwhile; ?>
        </select>
        <div class="invalid-feedback">Please select your blood type!</div>
    </div>

    <div>
        <label for="wilayaSelect" class="form-label mt-3">State</label>
        <select data-validator-func="wilayaValidator" name="wilaya" id="wilayaSelect" class="form-select" required>
            <option selected hidden style="display:none" value="">State</option>
            <?php while ($row = $wilayaresult->fetch_assoc()): ?>
                <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
            <?php endwhile; ?>
        </select>
        <div class="invalid-feedback">Please select a state!</div>
    </div>

    <div>
        <label for="dairaSelect" class="form-label mt-3">District</label>
        <select data-validator-func="dairaValidator" name="daira" id="dairaSelect" class="form-select" disabled required>
            <option selected hidden style="display:none" value="">District</option>
        </select>
        <div class="invalid-feedback">Please select a district!</div>
    </div>

    <div>
        <label for="id_phone" class="form-label mt-3">Phone Number</label>
        <input dir="auto" data-validator-func="phoneValidator" type="text" name="phone" maxlength="10" 
               class="form-control" required id="id_phone" value="" />
        <div class="invalid-feedback">Please enter a valid phone number!</div>
    </div>

    <div>
        <label for="id_email" class="form-label mt-3">Email</label>
        <input dir="auto" data-validator-func="emailValidator" type="email" name="email" maxlength="60" 
               class="form-control" required id="id_email" value="" />
        <div class="invalid-feedback emailInvalidFeedBack">Please enter a valid email!</div>
    </div>

    <div>
        <label for="id_password" class="form-label mt-3">Password</label>
        <input dir="auto" data-validator-func="passwordValidator" type="password" name="password" 
               class="form-control" required id="id_password" />
        <div class="invalid-feedback">Password must be at least 8 characters long!</div>
    </div>

    <div class="mb-3">
        <label for="id_confirm_password" class="form-label mt-3">Confirm Password</label>
        <input dir="auto" data-validator-func="passwordConfirmationValidator" type="password" 
               name="password_confirmation" class="form-control" required id="id_confirm_password" />
        <div class="invalid-feedback">This password does not match the previous one, both passwords must match!</div>
    </div>

    <div data-sitekey="6LdQLc0qAAAAANkSDDWaCy9zCr1_mO3wMpUY1U79" class="g-recaptcha"></div>

    <input class="btn btn-danger my-3 w-100" id="submitBtn" type="submit" value="Register" />
    <span class="text-dark d-block text-center">
        Already have an account? <a href="login.php" class="text-danger text-decoration-none">Log In</a>
    </span>

</form>
</div>


    <?php 
  include("footer.php");
?>

<link rel="modulepreload" href="build/assets/app.375cedd6.js" />
<script type="module" src="build/assets/app.375cedd6.js"></script>
       <link rel="modulepreload" href="build/assets/gettingDairas.549e3cbc.js" />
       <link rel="modulepreload" href="build/assets/registerPage.41a116f3.js" />
       <script type="module" src="build/assets/gettingDairas.549e3cbc.js">

       </script><script type="module" src="build/assets/registerPage.41a116f3.js">

       </script>
       <script src="https://www.google.com/recaptcha/api.js?hl=ar" async defer>

       </script>
              <script>

                   // Hide messages after 5 seconds
    setTimeout(function () {
        let alerts = document.querySelectorAll(".alert");
        alerts.forEach(alert => {
            alert.classList.remove("show");
            alert.classList.add("fade");
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
    // عند تغيير اختيار Province
    document.getElementById('wilayaSelect').addEventListener('change', function() {
        var wilayaId = this.value; // الحصول على قيمة Province المحددة
        var dairaSelect = document.getElementById('dairaSelect');

        // تمكين قائمة الدوائر بعد اختيار Province
        dairaSelect.disabled = false;

        // إرسال طلب AJAX للحصول على الدوائر بناءً على Province
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_dairas.php', true);  // هنا يجب أن يكون الملف الذي يحتوي على منطق جلب الدوائر
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status == 200) {
                dairaSelect.innerHTML = '<option selected hidden style="display:none" value="">Governorate</option>' + xhr.responseText;
            }
        };
        xhr.send('wilaya_id=' + wilayaId); // إرسال ID Province إلى الملف
    });



</script>

</body>

</html>
