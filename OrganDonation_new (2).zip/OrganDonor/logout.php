<?php
session_start();
session_unset(); // إزالة جميع بيانات الجلسة
session_destroy(); // تدمير الجلسة

// إعادة التوجيه إلى صفحة تسجيل الدخول
header("Location: login.php");
exit();
?>
