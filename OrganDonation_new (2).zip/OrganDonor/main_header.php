<div class="modal fade" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="contactModalLabel">Contact Us</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h5 class="text-center">Thank you for your interest in contacting us. You can send us a message on our Facebook page.</h5>
                <div class="d-flex justify-content-center">
                    <iframe src=""></iframe>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">
                    <a href="https://m.me/linatabara3" target="_blank" class="text-white text-decoration-none d-flex">
                        <svg style="width: 16px; margin-inline-end: 7px; fill: white;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                            <path d="M256.55 8C116.52 8 8 110.34 8 248.57c0 72.3 29.71 134.78 78.07 177.94 8.35 7.51 6.63 11.86 8.05 58.23A19.92 19.92 0 0 0 122 502.31c52.91-23.3 53.59-25.14 62.56-22.7C337.85 521.8 504 423.7 504 248.57 504 110.34 396.59 8 256.55 8zm149.24 185.13l-73 115.57a37.37 37.37 0 0 1-53.91 9.93l-58.08-43.47a15 15 0 0 0-18 0l-78.37 59.44c-10.46 7.93-24.16-4.6-17.11-15.67l73-115.57a37.36 37.36 0 0 1 53.91-9.93l58.06 43.46a15 15 0 0 0 18 0l78.41-59.38c10.44-7.98 24.14 4.54 17.09 15.62z"/>
                        </svg> Messenger
                    </a>
                </button>
            </div>
        </div>
    </div>
</div>

<nav class="navbar navbar-expand-xl navbar-light bg-white shadow-sm sticky-lg-top">
    <div class="container">
        <a class="navbar-brand d-flex" href="  ">
            <span class="mx-2">|</span>
            <img src="  imgs/linatabara3Logo.png" alt="Linatabara3 Logo" height="40px">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggler"
            aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarToggler">

            <div class="languageSwitcher text-center">
                
            </div>

            <ul class="navbar-nav mb-2 mb-lg-0 fw-bold">
    <?php
    $current_page = basename($_SERVER['PHP_SELF']);
    ?>

    <li class="nav-item">
        <a class="nav-link <?= ($current_page == 'index.php') ? 'active' : ''; ?>" href="index.php">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= ($current_page == 'organ_donors.php') ? 'active' : ''; ?>" href="organ_donors.php">Organ Donors List</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= ($current_page == 'about.php') ? 'active' : ''; ?>" href="about.php">About Us</a>
    </li>
    <li class="nav-item">
        <button type="button" class="nav-link btn btn-link" data-bs-toggle="modal" data-bs-target="#contactModal">
            Contact Us
        </button>
    </li>
</ul>


            <div class="d-flex flex-column flex-xl-row">
                <a href="register.php"
                   class="btn btn-danger btn-lg px-4 me-md-2 d-flex align-items-center justify-content-center">
                    Create Account <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                         class="bi bi-suit-heart-fill" viewBox="0 0 16 16">
                        <path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"/>
                    </svg>
                </a>
                <a href="login.php"
                   class="text-dark text-decoration-none d-flex align-items-center justify-content-center mt-3 ms-xl-4 mt-xl-0">My Account</a>
            </div>
        </div>
    </div>
</nav>
