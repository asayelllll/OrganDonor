<?php

    require_once "config.php"; // استدعاء ملف الاتصال بقاعدة البيانات

    // جلب فصائل الدم من قاعدة البيانات
    $query_organ_groups  = "SELECT * FROM organs_groups";
    $result_organs_groups = $conn->query($query_organ_groups);
    
    $query_blood_groups  = "SELECT * FROM blood_groups";
    $result_blood_groups = $conn->query($query_blood_groups);

?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_SESSION['user_id'])){
        $blood_group = $_POST['blood_group'];
        $gender = $_POST['gender'];
        $full_name = trim($_POST['full_name']);
        $Health_status = $_POST['Health_status'];
        $medical_conditions = isset($_POST['medical_conditions']) ? trim($_POST['medical_conditions']) : '';
        $type = $_POST['type'];
        $organs_group = ($type == "deceased") ? "عام" : $_POST['organs_groups'];
        $userid = $_SESSION['user_id'];
        $status = "Pending";

        if ($Health_status == "not_good") {
            $_SESSION['error'] = "You cannot donate because your health status is not good.";
            header("Location: organ_donor_register.php");
            exit();
        }

        $stmt = $conn->prepare("INSERT INTO organ_donors (user_id, donor_name, donor_gender, blood, organ, Health_status, medical_conditions, Donation_Status, status, donation_date) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

        $stmt->bind_param("issssssss", $userid, $full_name, $gender, $blood_group, $organs_group, $Health_status, $medical_conditions, $type, $status);

        if ($stmt->execute()) {
            $_SESSION['successs'] = "You have been successfully registered as an organ donor!";
            header("Location: index.php");
            exit();
        } else {
            $_SESSION['error'] = "An error occurred during registration, please try again.";
            header("Location: organ_donor_register.php");
            exit();
        }

        $stmt->close();
        $conn->close();
    } else {
        $_SESSION['error'] = "You must create an account first.";
        header("Location: organ_donor_register.php");
        exit();
    }
}
?>


<!doctype html>
<html lang="en" dir="ltr">
<head>

<title>Donate | Register as a Donor</title>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta property="og:description" content="Register as a donor">


    <meta property="og:type" content="website">
    <meta property="og:url" content=" register">
    <meta property="og:title" content="Donate | Register as a Donor">
    <meta property="og:description" content="Register as a donor">
    <meta property="og:image" content=" imgs/vialsOfBlood.jpg">
    <meta property="og:locale" content="ar_DZ">


    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content=" register">
    <meta property="twitter:title" content="لنتبرع | التسجيل كمتبرع">
    <meta property="twitter:description" content="التسجيل كمتبرع">
    <meta property="twitter:image" content=" imgs/vialsOfBlood.jpg">


    <link rel="alternate" href=" register" hreflang="ar" />
  


    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600&family=Nunito:wght@600;700&display=swap"
        rel="stylesheet">


            <link rel="stylesheet" href=" build/assets/bootstrap-rtl.6923a990.css" />

    <link rel="stylesheet" href=" css/app.css" />
        <link rel="stylesheet"  href=" css/registerPage.css" />


  




</head>

<body>

<?php
    include "header.php";
?>
<?php if (isset($_SESSION['error'])): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['error'];unset($_SESSION['error']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['successs'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['success'];unset($_SESSION['success']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

<?php endif; ?>
    <div class="formFieldsWrapper m-4">


        <form name="blod_donors" class="needs-validation" action="organ_donor_register.php" method="post" novalidate>

        <div class="form-group">
        <label for="full_name" class="form-label mt-2">Full Name</label>
        <input type="text" class="form-control" name="full_name" id="full_name" required>
    </div>
    <div class="form-group">
        <label class="form-label mt-2">Gender</label>
        <div>
            <input type="radio" name="gender" value="male" required> Male
            <input type="radio" name="gender" value="female" required> Female
        </div>
    </div>
    <div>
        <label for="id_blood_group" class="form-label mt-2">Blood Type</label>
        <select data-validator-func="bloodGroupValidator" name="blood_group" class="form-select" id="id_blood_group">
            <option selected hidden style="display:none" value="">Blood Type</option>
            <?php while ($row = $result_blood_groups->fetch_assoc()): ?>
                <option value="<?php echo $row['id'] ?>"><?php echo $row['bloodGroup'] ?></option>
            <?php endwhile; ?>
        </select>
        <div class="invalid-feedback">Please select your blood type!</div>
    </div>

            <div class="form-group">
            <label for="Health_status"  class="form-label mt-2">Health Status:</label>
            <div>
    <input type="radio"    name="Health_status" value="good" required> Good
    <input type="radio"   name="Health_status" value="not_good" required> Not Good
            </div>
            </div>

            <div class="form-group" id="additionalFields1" style="display: none;">
                <label for="medical_conditions"  class="form-label mt-2">  Enter any medications you are taking (if any)   </label>
                <input type="text" class="form-control" name="medical_conditions" id="medical_conditions" >
            </div>

            <div id="additionalFields" style="display: none;">
              <label  class="form-label mt-3">Donation Type:</label>
              <select name="type" id="donationType" class="form-select" required>
                <option  selected hidden style="display:none" value="" >Select Type</option>
                <option value="alive">Living (Partial Donation)</option>
                <option value="deceased">Deceased (Full Donation)</option>
              </select>
          
            </div>
            <div id="additionalFields2" style="display: none;">
            <div id="organField" style="display: none;">
            <label class="form-label mt-2">Organ Type:</label>
            <select name="organs_groups" class="form-select ">
                <option value="">Select Organ</option>
                <?php while ($row = $result_organs_groups->fetch_assoc()): ?>
                    <option value="<?php echo $row['id']; ?>"><?php echo $row['organs_name']; ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        </div>
  
            




            <div data-sitekey="6LdQLc0qAAAAANkSDDWaCy9zCr1_mO3wMpUY1U79" class="g-recaptcha"></div>

            <input class="btn btn-danger my-3 w-100" id="submitBtn" type="submit"
                value="Register" />


        </form>
    </div>

    <?php
        include "footer.php";
    ?>

<link rel="modulepreload" href="build/assets/app.375cedd6.js" />
<script type="module" src="build/assets/app.375cedd6.js"></script>
       <link rel="modulepreload" href="build/assets/gettingDairas.549e3cbc.js" />



       </script>
       <script src="https://www.google.com/recaptcha/api.js?hl=ar" async defer>

       </script>
       <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
              <script>
            setTimeout(function () {
        let alerts = document.querySelectorAll(".alert");
        alerts.forEach(alert => {
            alert.classList.remove("show");
            alert.classList.add("fade");
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
    jQuery(document).ready(function() {
        $('input[name="Health_status"]').change(function() {
            if ($(this).val() === "good") {
                $('#additionalFields').show();
                $('#additionalFields1').show();
                $('#additionalFields2').show();
            } else {
                $('#additionalFields').hide();
                $('#additionalFields1').hide();
                $('#additionalFields2').hide();
                alert("You cannot donate because your health status is not good.");
            }
        });
        
        $('#donationType').change(function() {
            if ($(this).val() === "deceased") {
                $('#organField').hide();
            } else {
                $('#organField').show();
            }
        });
    });


</script>

</body>

</html>
