tsParticles.loadJSON("tsparticles", window.location.origin + '/json/particlesjs-config.json')

