<section id="bloodDonationBenefitsSectino" class="bloodDonationBenefitsSectino">

<div class="container" data-aos="fade-up">

    <header class="section-header">
        <h1 class="text-danger">   Health Benefits of Organ Donation </h1>
        <p>  
        Organ donation is not only about saving the life of the recipient, but it can also have health and psychological benefits for the donor as well.
        </p>
    </header>

    <div class="row">

        <div class="col-12 col-lg-5 d-flex flex-column align-items-center mb-lg-5">
            <img src="  imgs/human-organ_bnf.svg" class="d-block mx-lg-auto img-fluid"
                alt="Bootstrap Themes" width="700" height="500" loading="lazy">

        </div>

        <div class="col-lg-7 mt-5 mt-lg-0 d-flex">
            <div class="row align-self-center gy-4">

                <div class="col-md-6" data-aos="zoom-out" data-aos-delay="200">
                    <div class="feature-box d-flex align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="33" height="33" fill="currentColor"
                            class="bi bi-check" viewBox="0 0 16 16">
                            <path
                                d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" />
                        </svg>
                        <h3>   Enhance the feeling of satisfaction and accomplishment</h3>
                    </div>
                </div>

                <div class="col-md-6" data-aos="zoom-out" data-aos-delay="300">
                    <div class="feature-box d-flex align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="33" height="33" fill="currentColor"
                            class="bi bi-check" viewBox="0 0 16 16">
                            <path
                                d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" />
                        </svg>
                        <h3>   Improve mental health through helping others</h3>
                    </div>
                </div>

                <div class="col-md-6" data-aos="zoom-out" data-aos-delay="400">
                    <div class="feature-box d-flex align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="33" height="33" fill="currentColor"
                            class="bi bi-check" viewBox="0 0 16 16">
                            <path
                                d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" />
                        </svg>
                        <h3>     Reduce stress and anxiety</h3>
                    </div>
                </div>

                <div class="col-md-6" data-aos="zoom-out" data-aos-delay="500">
                    <div class="feature-box d-flex align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="33" height="33" fill="currentColor"
                            class="bi bi-check" viewBox="0 0 16 16">
                            <path
                                d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" />
                        </svg>
                        <h3> Promote health awareness and regular medical follow-up for living donors</h3>
                    </div>
                </div>

                <div class="col-md-6" data-aos="zoom-out" data-aos-delay="600">
                    <div class="feature-box d-flex align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="33" height="33" fill="currentColor"
                            class="bi bi-check" viewBox="0 0 16 16">
                            <path
                                d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" />
                        </svg>
                        <h3>    Stimulate the body to adapt and regenerate tissues when donating part of the liver or kidney</h3>
                    </div>
                </div>

                <div class="col-md-6" data-aos="zoom-out" data-aos-delay="700">
                    <div class="feature-box d-flex align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="33" height="33" fill="currentColor"
                            class="bi bi-check" viewBox="0 0 16 16">
                            <path
                                d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" />
                        </svg>
                        <h3>  Support medical research and improve organ transplant treatments</h3>
                    </div>
                </div>

            </div>
        </div>

    </div>

</div>

</div>
</section>
