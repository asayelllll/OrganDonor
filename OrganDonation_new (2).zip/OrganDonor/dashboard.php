<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <head>
    <title>لنتبرع | حساب المتبرع</title>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="description" content="" />

    <meta property="og:type" content="website" />
    <meta property="og:url" content="" />
    <meta property="og:title" content="" />
    <meta property="og:description" content="" />
    <meta property="og:image" content="" />
    <meta property="og:locale" content="" />

    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:url" content="" />
    <meta property="twitter:title" content="" />
    <meta property="twitter:description" content="" />
    <meta property="twitter:image" content="" />

    <link rel="alternate" href="dashboard" hreflang="ar" />
    <link rel="alternate" href="fr/dashboard" hreflang="fr" />

    <link
      href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;600&family=Nunito:wght@600;700&display=swap"
      rel="stylesheet"
    />

    <link
      rel="preload"
      as="style"
      href="build/assets/bootstrap-rtl.6923a990.css"
    />
    <link rel="stylesheet" href="build/assets/bootstrap-rtl.6923a990.css" />
    <link rel="preload" as="style" href="build/assets/app.1fd5bbb5.css" />
    <link rel="stylesheet" href="build/assets/app.1fd5bbb5.css" />
    <meta name="robots" content="noindex,nofollow" />
    <link
      rel="preload"
      as="style"
      href="build/assets/userDashboard.2ee72fd6.css"
    />
    <link rel="stylesheet" href="build/assets/userDashboard.2ee72fd6.css" />
  
    <script data-turbo-eval="false">
      jQuery.noConflict(true);
    </script>

  </head>

  <body>
    <div
      class="modal fade"
      id="contactModal"
      tabindex="-1"
      aria-labelledby="contactModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="contactModalLabel">راسلنا</h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <h5 class="text-center">
              شكرا لاهتمامك بمراسلتنا، يمكنك إرسال رسالة لنا على صفحتنا على
              الفيسبوك.
            </h5>
            <div class="d-flex justify-content-center">
              <iframe
                src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Flinatabara3&tabs&width=340&height=130&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=913151315819800"
                width="340"
                height="130"
                style="border: none; overflow: hidden"
                scrolling="no"
                frameborder="0"
                allowfullscreen="true"
                allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
              ></iframe>
            </div>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              إغلاق
            </button>
            <button type="button" class="btn btn-primary">
              <a
                href="https://m.me/linatabara3"
                target="_blank"
                class="text-white text-decoration-none d-flex"
              >
                <svg
                  style="width: 16px; margin-inline-end: 7px; fill: white"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 512 512"
                >
                  <!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
                  <path
                    d="M256.55 8C116.52 8 8 110.34 8 248.57c0 72.3 29.71 134.78 78.07 177.94 8.35 7.51 6.63 11.86 8.05 58.23A19.92 19.92 0 0 0 122 502.31c52.91-23.3 53.59-25.14 62.56-22.7C337.85 521.8 504 423.7 504 248.57 504 110.34 396.59 8 256.55 8zm149.24 185.13l-73 115.57a37.37 37.37 0 0 1-53.91 9.93l-58.08-43.47a15 15 0 0 0-18 0l-78.37 59.44c-10.46 7.93-24.16-4.6-17.11-15.67l73-115.57a37.36 37.36 0 0 1 53.91-9.93l58.06 43.46a15 15 0 0 0 18 0l78.41-59.38c10.44-7.98 24.14 4.54 17.09 15.62z"
                  />
                </svg>
                Messenger
              </a>
            </button>
          </div>
        </div>
      </div>
    </div>

    <nav
      class="navbar navbar-expand-xl navbar-light bg-white shadow-sm sticky-lg-top"
    >
      <div class="container">
        <a class="navbar-brand d-flex" href="#">
          <img
            src="imgs/algerianMapFlag.svg"
            class="pb-2"
            alt="Algerian Map Flag"
            height="40px"
          />
          <span class="mx-2">|</span>
          <img
            src="imgs/linatabara3Logo.png"
            alt="Linatabara3 Logo"
            height="40px"
          />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarToggler"
          aria-controls="navbarToggler"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-between"
          id="navbarToggler"
        >
          <div class="languageSwitcher text-center">
            <a
              rel="alternate"
              hreflang="fr"
              href="fr/dashboard"
              style="font-family: 'Nunito', sans-serif"
              class="px-3 mt-2 mt-lg-0 btn btn-danger btn-sm py-1"
              >Francais</a
            >
          </div>

          <ul class="navbar-nav mb-2 mb-lg-0 fw-bold">
            <li class="nav-item">
              <a class="nav-link " aria-current="page" href="index.html">الرئيسية</a>
          </li>
          <li class="nav-item">
              <a class="nav-link " href="donors.html">قائمة المتبرعين</a>
          </li>
          <li class="nav-item">
              <a class="nav-link " href="about.html">من نحن</a>
          </li>
          
            <li class="nav-item">
              <button
                type="button"
                class="nav-link btn btn-link"
                data-bs-toggle="modal"
                data-bs-target="#contactModal"
              >
                راسلنا
              </button>
            </li>
          </ul>

          <div class="dropdown d-flex justify-content-center">
            <button
              class="btn btn-danger dropdown-toggle"
              type="button"
              id="accountDropDownMenu"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              mohamed771115574@gmail.com
            </button>
            <ul class="dropdown-menu" aria-labelledby="accountDropDownMenu">
              <li><a class="dropdown-item" href="dashboard">حسابي</a></li>

              <li>
                <form action="logout" method="post">
                  <input
                    type="hidden"
                    name="_token"
                    value="f98o4W5ahdyMR6uyl4nZPrX9qsOMRBvkUVYBSpsz"
                  />
                  <input
                    class="dropdown-item"
                    type="submit"
                    value="تسجيل الخروج"
                  />
                </form>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
    <div
      class="modal fade"
      id="passwordChangeModal"
      tabindex="-1"
      aria-labelledby="passwordChangeModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="passwordChangeModalLabel">
              تغيير كلمة المرور
            </h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <form
              name="userPasswordEditForm"
              id="userPasswordEditForm"
              class="needs-validation"
              action="user/password"
              method="post"
              novalidate
            >
              <input type="hidden" name="_method" value="put" />
              <input
                type="hidden"
                name="_token"
                value="f98o4W5ahdyMR6uyl4nZPrX9qsOMRBvkUVYBSpsz"
              />
              <div>
                <label for="id_password_current_password" class="form-label"
                  >كلمة المرور الحالية</label
                >
                <input
                  dir="auto"
                  data-validator-func="passwordValidator"
                  type="password"
                  name="current_password"
                  class="form-control"
                  required
                  id="id_password_current_password"
                />
                <div class="invalid-feedback">
                  الرجاء إدخال كلمة المرور الحالية الخاصة بك!
                </div>
              </div>

              <div>
                <label for="id_password" class="form-label mt-3"
                  >كلمة المرور الجديدة</label
                >
                <input
                  dir="auto"
                  data-validator-func="passwordValidator"
                  type="password"
                  name="password"
                  class="form-control"
                  required
                  id="id_password"
                />
                <div class="invalid-feedback">
                  يجب أن تكون كلمة المرور مكونة من 8 أحرف على الأقل !
                </div>
              </div>

              <div>
                <label for="id_confirm_password" class="form-label mt-3"
                  >إعادة إدخال كلمة المرور الجديدة</label
                >
                <input
                  dir="auto"
                  data-validator-func="passwordConfirmationValidator"
                  type="password"
                  name="password_confirmation"
                  class="form-control"
                  required
                  id="id_confirm_password"
                />
                <div class="invalid-feedback">
                  كلمة المرور هذه لا تتطابق مع كلمة المرور السابقة ، يجب أن تكون
                  كلمتا المرور متطابقتين !
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              إلغاء
            </button>
            <button
              type="submit"
              form="userPasswordEditForm"
              class="btn btn-danger"
            >
              حفظ
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="formFieldsWrapper m-4 p-4 rounded shadow-lg">
      <form
        name="userEditForm"
        class="needs-validation"
        action="user/profile-information"
        method="post"
        novalidate
      >
        <input
          type="hidden"
          name="_token"
          value="f98o4W5ahdyMR6uyl4nZPrX9qsOMRBvkUVYBSpsz"
        />
        <input type="hidden" name="_method" value="PUT" />

        <div>
          <label for="wilayaSelect" class="form-label mt-3">Province</label>
          <select
            data-validator-func="wilayaValidator"
            name="wilaya"
            id="wilayaSelect"
            class="form-select"
            required
          >
            <option value="" selected disabled>Province</option>
            <option value="1">1. أدرار</option>
            <option value="2">2. الشلف</option>
            
          </select>
          <div class="invalid-feedback">الرجاء اختيار ولاية !</div>
        </div>

        <div>
          <label for="dairaSelect" class="form-label mt-3">Governorate</label>
          <select
            data-validator-func="dairaValidator"
            name="daira"
            id="dairaSelect"
            class="form-select"
            disabled
            required
          >
            <option value="" selected disabled>Governorate</option>
          </select>
          <div class="invalid-feedback">الرجاء اختيار دائرة !!</div>
        </div>

        <div>
          <label for="id_phone" class="form-label mt-3">رقم الهاتف</label>
          <input
            dir="auto"
            data-validator-func="phoneValidator"
            type="text"
            name="phone"
            maxlength="10"
            class="form-control"
            required
            id="id_phone"
            value="0772426711"
          />
          <div class="invalid-feedback">من فضلك أدخل رقم هاتفك الصحيح !</div>
        </div>

        <div>
          <label for="id_email" class="form-label mt-3">الإيميل</label>
          <input
            dir="auto"
            data-validator-func="emailValidator"
            type="email"
            name="email"
            maxlength="60"
            class="form-control"
            required
            id="id_email"
            value="mohamed771115574@gmail.com"
          />
          <div class="invalid-feedback emailInvalidFeedBack">
            يرجى إدخال إميلك الصحيح !
          </div>
        </div>

        <div>
          <label class="form-label mt-3 d-block">تغيير كلمة المرور</label>
          <button
            type="button"
            class="btn btn-danger"
            data-bs-toggle="modal"
            data-bs-target="#passwordChangeModal"
          >
            تغيير كلمة المرور الخاصة بي
          </button>
        </div>

        <div class="form-check form-switch mt-4">
          <input
            name="ready_to_give"
            class="form-check-input"
            type="checkbox"
            id="readyToGive"
          />
          <label class="form-check-label" for="flexSwitchCheckDefault"
            >أنا مستعد لأتبرع</label
          >
          <span class="form-text d-block"
            >إذا كنت غير قادر على التبرع بالدم لسبب ما، يمكنك إيقاف تشغيل هذا
            الخيار ولن يظهر رقم هاتفك في نتائج البحث، يمكنك بالطبع إعادة تشغيله
            في أي وقت.</span
          >
        </div>

        <input
          class="btn btn-danger my-3 w-100"
          id="submitBtn"
          type="submit"
          value="حفظ"
        />
      </form>
    </div>

    <footer class="bg-dark">
      <div class="container d-flex flex-column align-items-center py-5">
        <a href="#"
          ><img
            src="imgs/linatabara3LogoWhite.png"
            alt="Linatabara3 Logo"
            height="40px"
        /></a>

        <div class="d-flex flex-column flex-sm-row align-items-center">
          <a
            class="footerLink text-decoration-none text-white px-3 mt-4 mt-sm-3"
            href="#"
            >الرئيسية</a
          >
          <a
            class="footerLink text-decoration-none text-white px-3 mt-3"
            href="donors"
            >قائمة المتبرعين</a
          >
          <a
            class="footerLink text-decoration-none text-white px-3 mt-3"
            href="about"
            >من نحن</a
          >
        </div>

        <div class="w-75">
          <p class="text-white mt-3 text-center fw-bold">
            هذا الموقع الجزائري يساعد المحتاجين إلى الدم في العثور على المتبرعين
            بكل سهولة وفي منطقتهم، هذا الموقع صدقة جارية، يرجى الدعاء لصاحبه
            ولكل من ساعد في تحقيقه بالرحمة والمغفرة.
          </p>
        </div>

        <span class="text-white">---</span>

        <div class="w-75">
          <p class="text-white mt-3 text-center">
            كود هذه المنصة مفتوح المصدر، يمكنك الحصول عليه كاملا على Github.
          </p>

          <div class="social-btns">
            <a
              class="btn github"
              href="https://github.com/theHocineSaad/linatabra3"
              rel="nofollow"
            >
              <svg
                class="fa-brands fa-github"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 496 512"
              >
                <!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
                <path
                  d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"
                />
              </svg>
            </a>
          </div>
        </div>

        <span class="text-white mt-3">تابعنا على:</span>
        <div
          class="findUsOnSocialMedia bg-dark d-flex justify-content-end align-items-center"
        >
          <div class="social-btns">
            <a
              class="btn facebook"
              href="https://www.facebook.com/linatabara3"
              target="_blank"
            >
              <svg
                class="fa-brands fa-facebook"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512"
              >
                <!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
                <path
                  d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"
                />
              </svg>
            </a>
            <a
              class="btn instagram"
              href="https://www.instagram.com/linatabara3/"
              target="_blank"
            >
              <svg
                class="fa-brands fa-instagram"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 448 512"
              >
                <!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
                <path
                  d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"
                />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </footer>

    <div class="visually-hidden" id="userWilayaCode">3</div>
    <div class="visually-hidden" id="userDairaCode">79</div>
    <div class="visually-hidden" id="userIsReadyToGive">1</div>

    <link rel="modulepreload" href="build/assets/app.375cedd6.js" />
    <script type="module" src="build/assets/app.375cedd6.js"></script>
    <link
      rel="modulepreload"
      href="build/assets/userDashboard.0e24726c.js"
    /><link rel="modulepreload" href="build/assets/gettingDairas.549e3cbc.js" />
    <script type="module" src="build/assets/userDashboard.0e24726c.js"></script>
    <script type="module" src="build/assets/gettingDairas.549e3cbc.js"></script>
  </body>
</html>
